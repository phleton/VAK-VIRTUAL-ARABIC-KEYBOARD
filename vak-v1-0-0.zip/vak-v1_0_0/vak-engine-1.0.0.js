﻿/**VAKengine.js*//**vak-engine-1.0.0.js*/
/*------------------------------
 -     VAK Engine              -
 -     Version: 1.0            -
 -     Year   : 2012           -
 -     Author : Kais Kara      -
 -  							-
 -  Revisions:					  -
 -	->Rev.2013:09.05.2013:>22:00:28 -
 -	->Rev.2020:31.01.2020:>18:50:00  -
 -	->Rev.2020:31.01.2020:>20:06:00  -
 -									 -
 -									 -
 -									-
 -								   -
 -								  -
 -------------------------------*/
 /**********function §(id){return document.getElementById(id);}
 * DOS.js *function €(id){return document.getElementById(id);}
 **********/function $(id){return document.getElementById(id);}
 /**************************
 * getting the screen size
 **************************/
/**vak-screen.js*/function setScreenSize(){/*Getting the screen size*/gScreenWidth=screen.width;gScreenHeight=screen.height;appConsole('->Screen-WIDTH/HEIGHT:['+gScreenWidth+'/'+gScreenHeight+']->px');}
/**vak-screen.js*/
/**vak-screen.js*/
/**vak-screen.js*/
/**HTML*/
/**HTML*/
/**HTML*/const BR='<br>',P='<p>';
/**HTML*/const TABLE='<table>',ELBAT='</table>';const TR='<tr>',RT='</tr>';const TD='<td>',DT='</td>';
/**HTML*/
/**HTML*/
/**constants*/const idAppLogoID					='appLogoImage';
/**constants*/const idKeyCombinationID			='appKeyCombination';
/**constants*/const idAppMainContainerID			='appMainContainer';
/**constants*/const idAppBackgroundImageID		='appBackgroundImage';
/**constants*/const idAppBtnSheeID				='appSheefamao';
/**constants*/const idAppTextAreaID				='appTextarea';
/**constants*/const idAppKeyboardID				='appKeyboard';
/**constants*/const idAppToolsID					='appTools';
/**constants*/const idAppWordsID					='appWords';
/**constants*/const idAppPrepositionsID			='appPrepositions';
/**constants*/const arrQuickWords=new Array('لا','يا','اللتي','أن','هذا','أين','لك','ماذا','لماذا');
/**constants*/const arrPrepositions=new Array('MIN','ILEH','3AAN','3ALEH','FIH','THOMA','7ATA','ME3A','FAW9A','TA7TA','THEDA','3ABRA','THLIKA','BA3DA','NAHWA','KYFA');
/**constants*/const arrKeyboardRow01=new Array("J","7","5","H","3","8","F","9","SX","DX");
/**constants*/const arrKeyboardRow02=new Array("K","M","N","T","A","L","B","Y","S","S'");
/**constants*/const arrKeyboardRow03=new Array("T'","T1","W","R","Z","D","D'","TA","ZA");
/**constants*/const arrKeyboardRow04=new Array("A","A3","A1","A2","W1","Y1","Y2","A4");
/**constants*/const arrKeyboardRow05=new Array(":",";","?");
/**constants*/const arrKeyboardRow06=new Array(".",",");
/**VARIABLES*/var gScreenWidth					=null;
/**VARIABLES*/var gScreenHeight					=null;
/**VARIABLES*/var isInfoSet						=false;
/**vak-function.js*/
/**vak-function.js*/
/**vak-function.js*/
function parseCssToInt(cssStr){var val=parseInt(cssStr.substring(0,3));return val;}
/**vak-function.js*/
/**vak-function.js*/
/**vak-function.js*/
/**vak-function.js*/
function loadApp(){buildTools();buildKeyboard();
	buildPreposition(idAppPrepositionsID,arrPrepositions);buildWords(idAppWordsID,arrQuickWords);
	setFocus_TextArea();
}
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*//*textarea->setFocus_*/function setFocus_TextArea(){var appArea=null;appArea=$(idAppTextAreaID);if(appArea!=null){appArea.focus();/*document.getElementById('_textarea').focus();*/}else{console.info('focus cannot be set!');}}
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
function keypressed(e){/*will be triggered whenever a key is pressed*/
	var pressChar=String.fromCharCode(e.keyCode);var arabChar=ConvertToArabChar(pressChar);
	e.preventDefault();writeCharacter(arabChar);
}
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*
/***********************************
 * Arabic alphabet (not optimized) *
 ***********************************/
/* var alphabet=new Array(
	getAlphabet("ALEF"),getAlphabet("BEH"),getAlphabet("TEH"),getAlphabet("THEH"),
	getAlphabet("JEEM"),getAlphabet("HAH"),getAlphabet("KHAH"),getAlphabet("DAL"),
	getAlphabet("THAL"),getAlphabet("REH"),getAlphabet("ZAIN"),getAlphabet("SEEN"),
	getAlphabet("SHEEN"),getAlphabet("SAD"),getAlphabet("DAD"),getAlphabet("TAH"),
	getAlphabet("ZAH"),getAlphabet("AIN"),getAlphabet("GHAIN"),getAlphabet("FEH"),
	getAlphabet("QAF"),getAlphabet("KAF"),getAlphabet("LAM"),getAlphabet("MEEM"),
	getAlphabet("NOON"),getAlphabet("HEH"),getAlphabet("WAW"),getAlphabet("YEH")
	);
*/
var alphabet=new Array(get("A"),get("B"),get("T"),get("T'"),
	get("J"),get("H"),get("5"),get("D"),
	get("D'"),get("R"),get("Z"),get("S"),
	get("S'"),get("SX"),get("DX"),get("TA"),
	get("ZA"),get("3"),get("8"),get("F"),
	get("9"),get("K"),get("L"),get("M"),
	get("N"),get("H"),get("W"),get("Y")
);
/*******************************************
 * Arabic special alphabet (not optimized) *
 *******************************************/
/* var specialAlphabet=new Array(
	getAlphabet("HAMZA"),
	getAlphabet("ALEF WITH MADDA ABOVE"),
	getAlphabet("ALEF WITH HAMZA ABOVE"),
	getAlphabet("ALEF WITH HAMZA BELOW"),
	getAlphabet("WAW WITH HAMZA ABOVE"),
	getAlphabet("TEH MARBUTA"),
	getAlphabet("ALEF MAKSURA"),
	getAlphabet("YEH WITH HAMZA ABOVE")
	);
*/
var specialAlphabet=new Array(get("A4"),get("A1"),get("A2"),get("A3"),get("W1"),get("T1"),get("Y1"),get("Y2"));
/*********************************
 * Arabic vowels (not optimized) *
 *********************************/var VOWEL=new Array("FATHA","KASRA","DAMMA","DAMMATAN","FATHATAN","KASRATAN","SCHADDA","SUKUN");
/******************
 * Arabic1 Number *
 ******************/var Numbers=["0","1","2","3","4","5","6","7","8","9"];
/***************************************
 * Arabic prepositions (not optimized) *
 ***************************************/
/*var PREPOSITION=new Array(
	getPrep("MIN"),
	getPrep("ILEH"),
	getPrep("3AAN"),
	getPrep("3ALEH"),
	getPrep("THOMA")
);*/
/***************************************
 * Get Arabic alphabet (not optimized) *
 ***************************************/
/*function getAlphabet(key){
var code='?';
	switch(key){
		case "ALEF": code="&#1575"; break; case "BEH": code="&#1576"; break;
		case "TEH": code="&#1578"; break; case "THEH": code="&#1579"; break;
		case "JEEM": code="&#1580"; break; case "HAH": code="&#1581"; break;
		case "KHAH": code="&#1582"; break; case "DAL": code="&#1583"; break;
		case "THAL": code="&#1584"; break; case "REH": code="&#1585"; break;
		case "ZAIN": code="&#1586"; break; case "SEEN": code="&#1587"; break;
		case "SHEEN": code="&#1588"; break; case "SAD": code="&#1589"; break;
		case "DAD": code="&#1590"; break; case "TAH": code="&#1591"; break;
		case "ZAH": code="&#1592"; break; case "AIN": code="&#1593"; break;
		case "GHAIN": code="&#1594"; break; case "FEH": code="&#1601"; break;
		case "QAF": code="&#1602"; break; case "KAF": code="&#1603"; break;
		case "LAM": code="&#1604"; break; case "MEEM": code="&#1605"; break;
		case "NOON": code="&#1606"; break; case "HEH": code="&#1607"; break;
		case "WAW": code="&#1608"; break; case "YEH": code="&#1610"; break;
		case "HAMZA": code="&#1569"; break;
		case "TEH MARBUTA": code="&#1577"; break;
		case "HAMZA": code="&#1569"; break;
		case "ALEF WITH MADDA ABOVE": code="&#1570"; break;
		case "ALEF WITH HAMZA ABOVE": code="&#1571"; break;
		case "WAW WITH HAMZA ABOVE": code="&#1572"; break;
		case "ALEF WITH HAMZA BELOW": code="&#1573"; break;
		case "YEH WITH HAMZA ABOVE": code="&#1574"; break;
		case "TEH MARBUTA": code="&#1577"; break;
		case "ALEF MAKSURA": code="&#1609"; break;
	default: break;
	}
return code;
}*/
/************
 **GetVowels*
 ************/
function getVowel(key){var vowel='?';
	switch(key){
		case "FATHATAN": vowel="&#1611"; break;
		case "DAMMATAN": vowel="&#1612"; break;
		case "KASRATAN": vowel="&#1613"; break;
		case "FATHA": vowel="&#1614"; break;
		case "DAMMA": vowel="&#1615"; break;
		case "KASRA": vowel="&#1616"; break;
		case "SCHADDA": vowel="&#1617"; break;
		case "SUKUN": vowel="&#1618"; break;
	}return vowel;
}
function getNumber(key){var num='?';
	switch(key){
		case "0": num="&#1632"; break;
		case "1": num="&#1633"; break;
		case "2": num="&#1634"; break;
		case "3": num="&#1635"; break;
		case "4": num="&#1636"; break;
		case "5": num="&#1637"; break;
		case "6": num="&#1638"; break;
		case "7": num="&#1639"; break;
		case "8": num="&#1640"; break;
		case "9": num="&#1641"; break;
	}
	return num;
}
function getPunctuation(key){var punct='?';
	switch(key){case ".":punct="."; break;
		case ',': punct="&#1548"; break;
		case ';': punct="&#1563"; break;
		case '?': punct="&#1567"; break;
		case ':': punct=":"; break;
	default: break;}
	return punct;
}
/********************************************
 * shortcut for arabic alphabet (optimized) *
 ********************************************/
function get(key){var c='?';
	switch(key){
		case "A": c="&#1575"; break; case "A1": c="&#1571"; break; case "A2": c="&#1573"; break;
		case "A3": c="&#1570"; break; case "A4": c="&#1569"; break;
		case "B": c="&#1576"; break;
		case "T": c="&#1578"; break; case "T1": c="&#1577"; break; case "T'": c="&#1579"; break;
		case "J": c="&#1580"; break; case "7": c="&#1581"; break;
		case "5": c="&#1582"; break; case "D": c="&#1583"; break;
		case "D'": c="&#1584"; break; case "R": c="&#1585"; break;
		case "Z": c="&#1586"; break; case "S": c="&#1587"; break;
		case "S'": c="&#1588"; break; case "SX": c="&#1589"; break;
		case "DX": c="&#1590"; break; case "TA": c="&#1591"; break;
		case "ZA": c="&#1592"; break; case "3": c="&#1593"; break;
		case "8": c="&#1594"; break; case "F": c="&#1601"; break;
		case "9": c="&#1602"; break; case "K": c="&#1603"; break;
		case "L": c="&#1604"; break; case "M": c="&#1605"; break;
		case "N": c="&#1606"; break; case "H": c="&#1607"; break;
		case "W": c="&#1608"; break; case "W1": c="&#1572"; break;
		case "Y": c="&#1610"; break; case "Y1": c="&#1609"; break; case "Y2": c="&#1574"; break;
	default: break;
	}
return c;
}
function getKeyExtra(key){var others='?';
	switch(key){case "SPACELABEL": others=get("M")+get("S")+get("A")+get("F")+get("T1"); break;
		case "SPACE": others="&#32;"; break;
		case "CRLABEL": others="CR"; break;
		case "CR": others="&#13;"; break;
	default: break;
	}
return others;
}
/*************************************************
 * Get Arabic preposition (not really optimized) *
 *************************************************/
function getPrep(key){var p='?';
	switch(key){
		case "MIN": p=get("M")+get("N") ; break;
		case "ILEH": p=get("A2")+get("L")+get("Y1"); break;
		case "3AAN": p=get("3")+get("N"); break;
		case "3ALEH": p=get("3")+get("L")+get("Y1"); break;
		case "FIH": p=get("F")+get("Y"); break;
		case "THOMA": p=get("T'")+get("M"); break;
		case "7ATA": p=get("7")+get("T")+get("Y1"); break;
		case "ME3A": p=get("M")+get("3"); break;
		case "TA7TA": p=get("T")+get("7")+get("T"); break;
		case "FAW9A": p=get("F")+get("W")+get("9"); break;
		case "THEDA": p=get("DX")+get("D"); break;
		case "3ABRA": p=get("3")+get("B")+get("R"); break;
		case "THLIKA": p=get("D'")+get("L")+get("K"); break;
		case "BA3DA": p=get("B")+get("3")+get("D"); break;
		case "NAHWA": p=get("N")+get("7")+get("W"); break;
		case "KYFA": p=get("K")+get("Y")+get("F"); break;
	default: break;
	}
return p;
}
/*******************
 * Write character *
 *******************/
function writeCharacter(character){var container=$(idAppTextAreaID);
	var selB,selE,cursorNextPos;
	setFocus_TextArea();
	selB=container.selectionStart;selE=container.selectionEnd;
	container.value=container.value.substr(0,selB)+character+container.value.substr(selE);
	cursorNextPos=selB+character.length;
	container.setSelectionRange(cursorNextPos,cursorNextPos);
	setFocus_TextArea();
}
/********************
 * Delete character *
 ********************/
function deleteCharacter(){var container=$(idAppTextAreaID);
	var cursorNextPos,selB,selE;
	if(container==null){return;}
	if(container!=null){setFocus_TextArea();}
	selB=container.selectionStart,selE=container.selectionEnd;
	if (selB==selE){container.value=container.value.substr(0,selB-1)+container.value.substr(selE);
		cursorNextPos=selB-1;}
	else{container.value=container.value.substr(0,selB)+container.value.substr(selE);
		cursorNextPos=selB;}
	container.setSelectionRange(cursorNextPos,cursorNextPos);
	if(container!=null){setFocus_TextArea();}
}
/*************************************************
 * Write word and append whitespace if necessary *
 *************************************************/
function writeWord(word){var container=$(idAppTextAreaID);
	setFocus_TextArea();
	var selB=container.selectionStart;
	var selE=container.selectionEnd;
	var prevW=container.value.substr(selB-1,1);
	var forwW=container.value.substr(selE,1);
	var appendW='';
	if((prevW!=" ")&&(selB>0)) appendW=" "
	appendW+=word;
	if(forwW!=" ")appendW+=" ";
	// console.log('*'+appendW+'*');
	container.value=container.value.substr(0,selB)+appendW+container.value.substr(selE);
	var cursorNextPos=selB+appendW.length;
	container.setSelectionRange(cursorNextPos,cursorNextPos);
	setFocus_TextArea();
}
/*************************
 * Clear->text->textarea *
 *************************/function clearText(){
	 var container=$(idAppTextAreaID);container.value='';setFocus_TextArea();}
/*****************
 * create button *
 *****************/function toButton(a,b){var input="<input type='button' value='%1' onclick='%2'>";return (input.replace(/%1/g,a)).replace(/%2/g,b);}
function ConvertToArabChar(key){/*convert to corresponding arabic alphabet*/var p='';
	switch(key){case "a": p="ا"; break;				case "A": p="ال"; break;
		case "e": p="أ"; break;				case "E": p="إ"; break;
		case "b": p="ب"; break;				case "B": p="ب"; break;
		case "t": p="ت"; break;				case "ö": p="ة"; break;
		case "T": p="ث"; break;
		case "g": p="ج"; break;
		case "7": p="ح"; break;
		case "5": p="خ"; break;
		case "c": p="ص"; break;				case "C": p="ض"; break;
		case "s": p="س"; break;				case "S": p="ش"; break;
		case "d": p="د"; break;				case "D": p="ذ"; break;
		case "f": p="ف"; break;
		case "q": p="ق"; break;				case "9": p="ق"; break;
		case "k": p="ك"; break;case "l": p="ل"; break;case "m": p="م"; break;case "n": p="ن"; break;
		case "p": p="ط"; break;case "P": p="ظ"; break;case "4": p="ظ"; break;
		case "y": p="ي"; break;				case "Y": p="ى"; break;
		case "h": p="ه"; break;
		case "r": p="ر"; break;case "R": p="ز"; break;case "z": p="ز"; break;
		case "2": p="ع"; break;case "3": p="غ"; break;
		case "w": p="و"; break;case "u": p="او"; break;case "o": p="او"; break;
		case "1": p="ء";
		break;case ",": p="،"; break;case ".": p="."; break;
		default: p=key; break;
	}return p;
}
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************
 * Build preposition section *
 *****************************/
function buildPreposition(id,list){var container=$(id);
	var btnWord="<input type='button' value='%PARM' class='' onclick='writeWord(\"%PARM\")'>"
	var append='',block='';
	append+="<table><tr>";
		var i=0,j=0;
		while((2*i+j)<list.length){
		append+=TD;
			while (((j/2)!=1)&&((2*i+j)<list.length)){
				block=btnWord.replace(/%PARM/g,getPrep(list[2*i+j]));
				append+=block;
				j++;
			}i++;j=0;append+=DT;
		}
	append+=RT+ELBAT;
	if (container!=null){container.innerHTML=append;}
}
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************
 * Build preposition section *
 * Build preposition section *
 *****************************/
function buildWords(id,list){var container=$(id);var i=0,j=0;var table='',tableCol;
	var btnWord="<input type='button' value='%PARM' class='_prep' onclick='writeWord(\'%PARM\')'>"
	table+=TABLE;
	while((4*i)<list.length){table+=TR;
		while (((j/4)!=1)&&((4*i+(j+1))<list.length)){
			table+=TD;tableCol=btnWord.replace(/%PARM/g,list[4*i+j]);
			table+=tableCol;table+=DT;j++;
		}table+=RT;i++;j=0;
	}table+=ELBAT;container.innerHTML=table;
}
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************
 * Build preposition section *
 * Build preposition section *
 *****************************/
function buildTools(){var tools=$(idAppToolsID),table='';
	table+=''+
	toButton('إبحث في DuckDuckGo','searchOnDuckDuckGo()')+
	toButton('إبحث في Youtube','searchOnYoutube()')+
	toButton('إبحث في Bing','searchOnBing()')+
	toButton('إبحث في Google','searchOnGoogle()')
	+BR+
	toButton('مسح اللوحة','clearText()');
	tools.innerHTML+=table;
}
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/**vak-search.js*/
/**vak-search.js*/
/**********************
 * Searching function *
 **********************/
	function searchOnDuckDuckGo()	{return searchOnInternet(1);}
	function searchOnBing()			{return searchOnInternet(2);}
	function searchOnYoutube()		{return searchOnInternet(3);}
	function searchOnGoogle()		{return searchOnInternet(4);}
/**********************
*Searching function *
 *****************************************************************************************/
	function searchOnInternet(id){const HTTP_WWW='http://www.';
		var url='',query=$(idAppTextAreaID).value;
		switch(id){
		  /*search on duckduckgo*/case 1 :url='https://duckduckgo.com/?q='						+query;break;
		  /*search on bing*_____*/case 2 :url='http://www.bing.com/search?q='					+query;break;
		  /*search on youtube___*/case 3 :url='http://www.youtube.com/results?search_query='	+query;break;
		  /*search on Google____*/case 4 :url='http://www.google.com/#hl=ar&output=search&q='	+query;	break;
		  /**default:google*____*/default:url='http://www.google.com/#hl=ar&output=search&q='	+query;break;
		}window.open(url);
	}
/*                                                                                       */
/*****************************************************************************************/
/**vak-search.js*/
/**vak-search.js*/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/******************/function showMenu(myArea){/*showing the menu*/var submenu=$(myArea);if(submenu!=null)submenu.style.display='block';}
/* Menu functions */function hideMenu(myArea){/*hidding the menu*/var submenu=$(myArea);if(submenu!=null)submenu.style.display='none';}
/******************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/****************
 * Showing Info *
 ****************/
function showInfo(placeHolder){/*show or hide info*/var tag=$(placeHolder);
	if(tag != null){if (!isInfoSet){isInfoSet=true;
			tag.style.visibility='visible';
			var tHeight=tag.style.height;
			var tWidth=tag.style.width;
			console.log("width: "+tWidth+" height: "+tHeight);
			var tTop=200;/*(screenH/8)+(parseCssToInt(tHeight)/2);*/
			var tRight=(screenW * 0.5) - (parseCssToInt(tWidth) * 0.5);
			console.log("top: "+tTop+" right: "+tRight);
			tag.style.top=tTop+"px";
			tag.style.right=tRight+"px";
			//tag.style.display='show';
		} else{tag.style.visibility='hidden';/*tag.style.display='none';*/isInfoSet=false;}
	}
}
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************
 * Buid keyboard *
 *****************/
	// var arrKeyboardRow01=new Array("J","7","5","H","3","8","F","9","SX","DX");
	// var arrKeyboardRow02=new Array("K","M","N","T","A","L","B","Y","S","S'");
	// var arrKeyboardRow03=new Array("T'","T1","W","R","Z","D","D'","TA","ZA");
	// var arrKeyboardRow04=new Array("A2","A3","A1","W1","Y1","Y2","A4");
	// var arrKeyboardRow05=new Array(":",";","?");
	// var arrKeyboardRow06=new Array(".",",");
	/******************************************
	 * Helping function to build Keyboard Row *
	 ******************************************/
	function makeKeyboardRow(arr,a){
		var tag="<input type='button' value='%PARM' class='_druckZeichen' onclick='writeCharacter(\"%PARM\")'>";
		var block='';
		var dest='';
		for(var i=(arr.length-1);i>=0;i--){block=tag;block=block.replace(/%PARM/g,a(arr[i]));dest+=block;}
		return dest;
	}
	/*******************************
	* building the arabic keyboard *
	********************************/
	function buildKeyboard(){var tastatur=$("appKeyboard");
		var tag="<input type='button' value='%PARM' class='appKeyboard_DruckZeichen' onclick='writeCharacter(\"%PARM\")'>";
		var block;
		var append='';
		// arabic vowels
		append+=makeKeyboardRow(VOWEL,getVowel)+"<p>";
		// arabic letters
		append+=makeKeyboardRow(arrKeyboardRow01,get)+"<br>"+makeKeyboardRow(arrKeyboardRow02,get)+"<br>";
		append+=makeKeyboardRow(arrKeyboardRow03,get)+"<br>"+makeKeyboardRow(arrKeyboardRow04,get);
		append+="<input type='button' value='مسح' class='appKeyboard_Delete' onclick='deleteCharacter()'>";
		// punctuation
		append+=BR+makeKeyboardRow(arrKeyboardRow05,getPunctuation);
		var ta="<input type='button' value='%PARM1' class='appKeyboard_Backspace' onclick='writeCharacter(\"%PARM2\")'>";
		var keyboardREST=new Array("SPACE");
		var keyboardLABEL=new Array("SPACELABEL");
		for (var i=(keyboardREST.length-1); i>=0; i--){
			block=ta;
			block=block.replace(/%PARM1/g,getKeyExtra(keyboardLABEL[i]));
			block=block.replace(/%PARM2/g,getKeyExtra(keyboardREST[i]));
			append+=block;
		}
		append+=makeKeyboardRow(arrKeyboardRow06,getPunctuation)+"<br>";
		append+="<p/>";
		append+=makeKeyboardRow(Numbers,getNumber)+"<p>";
		tastatur.innerHTML=append;
	}
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/
/*****************************************************************************************/