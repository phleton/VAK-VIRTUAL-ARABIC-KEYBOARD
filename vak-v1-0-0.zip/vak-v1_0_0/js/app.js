﻿/*-----------------------------------*
 *-     THE VAK Engine          	-*
 *-     Version:1.0.0         		-*
 *-     Year:2012-2013,2019-2020 	-*
 *-     Author:Kais el Kara 		-*
 *-----------------------------------*/
const APP_NAME='[VAK]';
const APP_VERSION='[1.0.0]';
/**vak.js*/
/**vak-dos.js*/
/**vak-screen.js*/
/**vak-lang-ar.js*/
/**vak-preposition.js*/
/**vak-words.js*/
/**vak-textarea.js*/
/**vak-textarea-cursor.js*/
/**vak-keyboard.js*/
/**vak-.js*/
/**vak-.js*/
/**vak-menu.js*/
/**vak-info.js*/
/**vak-search.js*/
/**vak-tools.js*/
/**LOADING-APP*/
/**LOADING-APP*/
/**LOADING-APP*/
function appConsole(msg){return console.info(APP_NAME+msg);}
function appConsoleError(msg){return console.error(APP_NAME+msg);}
function loadApp(){appConsole('-starting..')
	loadComponents();
	loadLogos(LOGO_ISL,arrLogos,[1,1,1,1]);
	appConsole('-started::[SUCCESSFULLY]')
}
function loadComponents(){
	appConsole('->loading->COMPONENTS')
	loadComponent_Screen();
	loadComponent_TextArea()
	loadComponent_Tools();
	loadComponent_Language()
	loadComponent_Keyboard();
	appConsole('->components[LOADED]')
}
