/**vak-cursor.js*/
/**vak-cursor.js*/
/**CURSOR-SELECTION*/
/**CURSOR-SELECTION*/
/**VARIABLES*/var gSelectBegin			=null;
/**VARIABLES*/var gSelectEnd			=null;
/**VARIABLES*/var gCursorNextPos		=null;
/**CURSOR-SELECTION*/
/**CURSOR-SELECTION*/
/**vak-cursor.js*/
/**vak-cursor.js*/