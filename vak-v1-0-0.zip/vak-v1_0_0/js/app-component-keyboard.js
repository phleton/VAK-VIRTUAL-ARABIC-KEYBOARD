/* Buid keyboard*/
/* Buid keyboard*/
/* Buid keyboard*/
/* Buid keyboard*/
/**variable*/var btnBackspace="<input type='button' value='%PARM1' class='"+KEYBOARD_BACKSPACE+"' onclick='writeCharacter(\'%PARM2\')'>";
/**variable*/var btnDelete="<input type='button' value='مسح' class='"+KEYBOARD_DEL+"' onclick='deleteCharacter()'>"
function buildKeyboard(){var newKeyRow=null;
	var keyboardREST=new Array('SPACE');
	var keyboardLABEL=new Array('SPACELABEL');
	newKeyRow=''
	+addKeyboardRow(Numbers,'getNumber')+HTML_BREAK
	+addKeyboardRow(VOWEL,'getVowel')+HTML_NEWLINE
	+addKeyboardRow(arrKeyboardRow01,'getElem')+HTML_BREAK
	+addKeyboardRow(arrKeyboardRow02,'getElem')+HTML_BREAK
	+addKeyboardRow(arrKeyboardRow03,'getElem')+HTML_BREAK
	+addKeyboardRow(arrKeyboardRow04,'getElem')
	+btnDelete+'';
	/*punctuation*/newKeyRow+=HTML_BREAK+addKeyboardRow(arrKeyboardRow05,'getPunctuation');
	for (var i=(keyboardREST.length-1);i>=0;i--){
		newKeyRow+=btnBackspace.replace(/%PARM1/g,getSpecialCharacter(keyboardLABEL[i])).replace(/%PARM2/g,getSpecialCharacter(keyboardREST[i]));
	}
	newKeyRow+=addKeyboardRow(arrKeyboardRow06,'getPunctuation')+HTML_BREAK
	newKeyRow+=HTML_NEWLINE;
	addToComponent(gAppID_Keyboard,gAppComponent_Keyboard,newKeyRow);
}
function addKeyboardRow(arr,a){/* Helping function to build Keyboard Row */
	/*var btnKey="<input type='button' value='%PARM' class='DruckZeichen' onclick='writeCharacter(\'%PARM\')'>";*/
	var funcNAME1='writeCharacter("%PARM")';
	var newRow='';
	var c='',d='';
	for(var i=(arr.length-1);i>=0;i--){
		c=arr[i];
		if(a=='getVowel'){d=getVowel(c);}
		else if(a=='getElem'){d=getElem(c);}
		else if(a=='getPunctuation'){d=getPunctuation(c);}
		else if(a=='getNumber'){d=getNumber(c);}
		else{d=get(c);}
		// appConsoleError('::'+c+'::'+d);
		appConsole('::'+c+'::'+d);
		funcNAME1=FUNC_NAME0.replace(/%PARM/g,d);
		newRow+=toButtonWithCSS(d,DRUCKZEICHEN,funcNAME1);;
	}
	return newRow;
}