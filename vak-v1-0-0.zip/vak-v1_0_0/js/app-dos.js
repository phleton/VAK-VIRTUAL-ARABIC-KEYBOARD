/**DOS*/
/**DOS*/
/**DOS*/function get(id)	{return document.getElementById(id);}
/**DOS*/function create(id)	{return document.createElement(id);}
/**DOS*/
/**DOS*/
/**DOS*/
/**DOS*/
/**DOS*/