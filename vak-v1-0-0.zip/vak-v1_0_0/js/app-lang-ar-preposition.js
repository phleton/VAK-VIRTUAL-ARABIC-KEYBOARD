/**Constants*/const ROW_LENGTH=4;
/**ARRAY____*/var gArrPrepositions=new Array('MIN','ILEH','3AAN','3ALEH','FIH','THOMA','7ATA','ME3A','FAW9A','TA7TA','THEDA','3ABRA','THLIKA','BA3DA','NAHWA','KYFA');
function buildPreposition(){
	appConsole('->building->preposition(s)');
	var table,tableRow,tableCol;
	var btn="<input type='button' value='%PARM' class='appPreposition'"
	+"onclick='writeWord(\'%PARM\')'>"
	var list=gArrPrepositions,table='',block,row=0,col=0;
	table=create('table');
	while((ROW_LENGTH*row+col)<list.length){
		tableRow=create('tr');
		while(((col/ROW_LENGTH)!=1)&&((ROW_LENGTH*row+col)<list.length)){
			tableCol=create('td');
			tableCol.innerHTML=btn.replace(/%PARM/g,getPreposition(list[ROW_LENGTH*row+col]));
			tableRow.appendChild(tableCol);
			col++;
		}row++;col=0;
		table.appendChild(tableRow);
	};
	if(gAppComponent_Preposition!=null){
		gAppComponent_Preposition.appendChild(table);
	}
}
function getPreposition(key){/*Get Arabic preposition (not really optimized)*/
	var p='_';
	switch(key){
		case 'MIN': p=getElem('M')+getElem('N') ; break;
		case 'ILEH': p=getElem('A2')+getElem('L')+getElem('Y1'); break;
		case '3AAN': p=getElem('3')+getElem('N'); break;
		case '3ALEH': p=getElem('3')+getElem('L')+getElem('Y1'); break;
		case 'FIH': p=getElem('F')+getElem('Y'); break;
		case 'THOMA': p=getElem("T'")+getElem('M'); break;
		case '7ATA': p=getElem('7')+getElem('T')+getElem('Y1'); break;
		case 'ME3A': p=getElem('M')+getElem('3'); break;
		case 'TA7TA': p=getElem('T')+getElem('7')+getElem('T'); break;
		case 'FAW9A': p=getElem('F')+getElem('W')+getElem('9'); break;
		case 'THEDA': p=getElem('DX')+getElem('D'); break;
		case '3ABRA': p=getElem('3')+getElem('B')+getElem('R'); break;
		case 'THLIKA': p=getElem("D'")+getElem('L')+getElem('K'); break;
		case 'BA3DA': p=getElem('B')+getElem('3')+getElem('D'); break;
		case 'NAHWA': p=getElem('N')+getElem('7')+getElem('W'); break;
		case 'KYFA': p=getElem('K')+getElem('Y')+getElem('F'); break;
		default: break;
	}
	return p;
}