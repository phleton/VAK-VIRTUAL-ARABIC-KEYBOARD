/**app-logo.js*/
/**app-logo.js*/
/**dependency->app-dos.js*/
/**nodependency->app-html.js*/
function loadLogos(parLogoImage,parArrLogos,parArrMatrix){
	var div=null;
	for (var i=0;i<parArrMatrix.length;i++){
		if(parArrMatrix[i]==1){
			div=get(parArrLogos[i]);
			div.appendChild(createImage(parLogoImage));
		}
	}
}