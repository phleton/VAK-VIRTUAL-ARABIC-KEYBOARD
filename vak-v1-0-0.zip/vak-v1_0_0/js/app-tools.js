/**dependency->app-ui.js*/
const CLEAR_WALL='مسح اللوحة';
const FUNC_CALLED='clearText()';
function buildTools(){var plainButton='',repeat=5;
	for(var i=0;i<repeat;i++){plainButton+=toButton(CLEAR_WALL,FUNC_CALLED);}
	addToComponent(gAppID_ToolsUp,gAppComponent_ToolsUp,plainButton);
}
