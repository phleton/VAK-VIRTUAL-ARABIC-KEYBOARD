function searchOn(searchEngine){
	var url='http://',search=getSearchText(),query=search;
		 if(searchEngine=='')		 {}
	else if(searchEngine=='duckduckgo')
		{url+='www.duckduckgo.com/search?q='+query;}
	else if(searchEngine=='youtube') {url+='www.youtube.com/results?search_query='+query;}
	else if(searchEngine=='bing')	 {url+='www.bing.com/search?q='+search;}
	else if(searchEngine=='google')	 {url+='www.google.com/search?q='+query;}
	else							 {url+='noodle.phleton.com/search.io?q='+query}
	/*window.open(url,'_blank');*/
	window.open(url);
}
function buildToolsSearch(){plainButtons=''
	+toButton('إبحث في Google', 'searchOn("google")')
	/*+toButton('إبحث في DuckDuckGo', 'searchOn("duckduckgo")')*/
	+toButton('إبحث في Youtube', 'searchOn("youtube")')
	+toButton('إبحث في Bing', 'searchOn("bing")')
	/*+toButton('إبحث في Google', 'searchOn("google")')*/
	+'';
	addToComponent(gAppID_ToolsUp,gAppComponent_ToolsDown,plainButtons);
}