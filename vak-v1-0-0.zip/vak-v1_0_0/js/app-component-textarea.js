/**vak-textarea.js*/
function keypressed(e){/*triggeredWheneverKeyPressed*/
	var a,b;a=String.fromCharCode(e.keyCode);b=ConvertToArabChar(a);
	appConsole('->'+a+'->:'+b);e.preventDefault();writeCharacter(b);
}
function setFocus(){gAppComponent_TextArea.focus();}
function getSearchText(){var searchContent=gAppComponent_TextArea.value;
	return searchContent;
}
function clearText(){/*Clear written text in the text area*/gAppComponent_TextArea.value='';setFocus();}
function writeCharacter(character){/* Write character */
	setFocus();
	gSelectBegin=gAppComponent_TextArea.selectionStart,gSelectEnd=gAppComponent_TextArea.selectionEnd;
	gAppComponent_TextArea.value=gAppComponent_TextArea.value.substr(0,gSelectBegin)+character+gAppComponent_TextArea.value.substr(gSelectEnd);
	gCursorNextPos=gSelectBegin+character.length;
	gAppComponent_TextArea.setSelectionRange(gCursorNextPos,gCursorNextPos);
	setFocus();
}
function deleteCharacter(){/*Delete character*/
	setFocus();
	gSelectBegin=gAppComponent_TextArea.selectionStart;
	gSelectEnd=gAppComponent_TextArea.selectionEnd;
	if(gSelectBegin==gSelectEnd){gAppComponent_TextArea.value=gAppComponent_TextArea.value.substr(0,gSelectBegin-1)+gAppComponent_TextArea.value.substr(gSelectEnd);gCursorNextPos=gSelectBegin-1;}
	else{gAppComponent_TextArea.value=gAppComponent_TextArea.value.substr(0,gSelectBegin)+gAppComponent_TextArea.value.substr(gSelectEnd);gCursorNextPos=gSelectBegin;}
	gAppComponent_TextArea.setSelectionRange(gCursorNextPos,gCursorNextPos);
	setFocus();
}