/**vak-screen.js*/
/**vak-screen.js*/
function setScreenSize(){/*Getting the screen size*/
	gScreenWidth=screen.width;gScreenHeight=screen.height;
	appConsole('->Screen-WIDTH/HEIGHT:['+gScreenWidth+'/'+gScreenHeight+']->px');
}
/**vak-screen.js*/
/**vak-screen.js*/