function createAudio(source){
	var audio=null;audio=new Audio();
	audio.src=source;
	return audio;
}