/**vak-menu.js*/
/*Menu functions*/function showMenu(larea){/*showing the menu*/var submenu=get(larea);if(submenu!=null)submenu.style.display='block';}
/*Menu functions*/function hideMenu(larea){/*hidding the menu*/var submenu=get(larea);if(submenu!=null)submenu.style.display='none';}
/**vak-menu.js*/