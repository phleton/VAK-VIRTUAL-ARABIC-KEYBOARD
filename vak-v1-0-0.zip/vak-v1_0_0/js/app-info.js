var isInfoSet=false;
function showInfo(placeHolder){/*show or hide info*/
	var tHeight=null,tTop=null,tRight=null,tag=get(placeHolder);
	if(tag!=null){
		if(!isInfoSet){isInfoSet=true;
		tag.style.visibility='visible';
		tHeight=tag.style.height,_tWidth=tag.style.width;
		console.info('width: '+_tWidth+' height: '+tHeight);
		tTop=200;/*(gScreenHeight/8)+(parseCssToInt(tHeight)/2);*/
		tRight=(gScreenWidth*0.5)-(parseCssToInt(tWidth)*0.5);
		console.info('top: '+tTop+' right: '+tRight);
		tag.style.top=tTop+'px';
		tag.style.right=tRight+'px';
		/*tag.style.display='show';*/
		}else{tag.style.visibility='hidden';/*tag.style.display='none';*/
		isInfoSet=false;}
	}
}