/**vak-words.js*/
/**vak-words.js*/
/**ARRAY____*/const gArrQuickWords=new Array("لا", "يا", "اللتي", "أن", "هذا", "أين", "لك", "ماذا", "لماذا");
function buildWords(){var arrWords=gArrQuickWords;
	var btnQuickWord="<input type='button' value='%PARM'"// class='appPreposition'"
		+"onclick='writeWord(\"%PARM\")'>"
	var i=0,j=0,table=null,rows=null;cols=null;row=null,col=null;
	table=HTML_TABLE_OPENED+SYMBOL+HTML_TABLE_CLOSED;
	// node=create('table');
	while((4*i)<arrWords.length){row=HTML_TABLE_ROW_OPENED+SYMBOL+HTML_TABLE_ROW_CLOSED;
		while(((j/4)!=1)&&((4*i+(j+1))<arrWords.length)){
			col=HTML_TABLE_COL_OPENED+btnQuickWord.replace(/%PARM/g,arrWords[4*i+j])+HTML_TABLE_COL_CLOSED;
			cols+=col;j++;
		}
		rows+=row.replace(SYMBOL,cols);i++;j=0;
	}table=table.replace(SYMBOL,rows);
	addToComponent(gAppID_Words,gAppComponent_Words,table);
}
function writeWord(word){/*Write word and append whitespace if necessary*/
	var prevWord=null,forWord=null,appendWord=null;
	gSelectBegin	=gAppTextArea.selectionStart;
	gSelectEnd		=gAppTextArea.selectionEnd;
	prevWord		=gAppTextArea.value.substr(gSelectBegin-1,1);
	forWord			=gAppTextArea.value.substr(gSelectEnd,1);
	appendWord='';
	setFocus();
	if((prevWord!=' ')&&(gSelectBegin>0)){appendWord=' ';}
	appendWord+=word;
	if(forWord!=' ')appendWord+=' ';/*console.info('*'+appendWord+'*');*/
	gAppTextArea.value=gAppTextArea.value.substr(0,gSelectBegin)
		+appendWord+gAppTextArea.value.substr(gSelectEnd);
	gCursorNextPos=gSelectBegin+appendWord.length;
	gAppTextArea.setSelectionRange(gCursorNextPos,gCursorNextPos);
	setFocus();
}