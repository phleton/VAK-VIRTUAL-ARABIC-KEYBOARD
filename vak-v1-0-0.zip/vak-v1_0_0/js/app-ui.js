/**app-ui.js*/
/**dependency->app-html.js*/
function createImage(source){var img=null;img=create('img');
	img.src=source;
	img.alt=''
	/*img.width='';img.height='';*/
	return img;
}
function createButton(a,b){var elem=create('input');
	elem.type='button';elem.value=a;/*elem.onclick=b;*/return elem;
}
function createCheckbox(a,b){var elem=create('input');
	elem.type='button';elem.value=a;/*elem.onclick=b;*/return elem;
}