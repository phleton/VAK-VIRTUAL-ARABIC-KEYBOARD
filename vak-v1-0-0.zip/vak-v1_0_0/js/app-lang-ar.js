/*Arabic alphabet (not optimized)
Rev.2020.0:30.01.2020>18:42:22>create>app-lang-ar.js
Rev.2020.1:31.01.2020>23:12:50>?>fixed>shortcut>keyboard
Rev.2020.2:05.02.2020>13:22:19>i/I>switched
Rev.2020.2:05.02.2020>13:25:~~>?>changed>arabic
Rev.2020.2:05.02.2020>13:31:~~>?>change>completed>key6/8/?
*/
/* var alphabet=new Array(getAlphabet('ALEF'),getAlphabet('BEH'),getAlphabet('TEH'),getAlphabet('THEH'),
				getAlphabet('JEEM'),getAlphabet('HAH'),getAlphabet('KHAH'),getAlphabet('DAL'),
				getAlphabet('THAL'),getAlphabet('REH'),getAlphabet('ZAIN'),getAlphabet('SEEN'),
				getAlphabet('SHEEN'),getAlphabet('SAD'),getAlphabet('DAD'),getAlphabet('TAH'),
				getAlphabet('ZAH'),getAlphabet('AIN'),getAlphabet('GHAIN'),getAlphabet('FEH'),
				getAlphabet('QAF'),getAlphabet('KAF'),getAlphabet('LAM'),getAlphabet('MEEM'),
				getAlphabet('NOON'),getAlphabet('HEH'),getAlphabet('WAW'),getAlphabet('YEH'));
*/
var alphabet=new Array(get('A'),get('B'),get('T'),get("T'"),
get('J'),get('H'),get('5'),get('D'),
get("D'"),get('R'),get('Z'),get('S'),
get("S'"),get('SX'),get('DX'),get('TA'),
get('ZA'),get('3'),get('8'),get('F'),
get('9'),get('K'),get('L'),get('M'),
get('N'),get('H'),get('W'),get('Y')
);
/*Arabic special alphabet (not optimized)*/
/*var specialAlphabet=new Array(getAlphabet('HAMZA'),
getAlphabet('ALEF WITH MADDA ABOVE'),getAlphabet('ALEF WITH HAMZA ABOVE'),
getAlphabet('ALEF WITH HAMZA BELOW'),
getAlphabet('WAW WITH HAMZA ABOVE'),
getAlphabet('TEH MARBUTA'),getAlphabet('ALEF MAKSURA'),
getAlphabet('YEH WITH HAMZA ABOVE'));*/
var specialAlphabet=new Array(get('A4'),get('A1'),get('A2'),get('A3'),get('W1'),get('T1'),get('Y1'),get('Y2'));
var VOWEL=new Array('FATHA','KASRA','DAMMA','DAMMATAN','FATHATAN','KASRATAN','SCHADDA','SUKUN');
var Numbers=new Array('0','1','2','3','4','5','6','7','8','9');
/* Arabic prepositions (not optimized) */
/*var PREPOSITION=new Array(getPrep('MIN'),getPrep('ILEH'),getPrep('3AAN'),getPrep('3ALEH'),getPrep('THOMA'));*/
/* Get Arabic alphabet (not optimized) **/
/*function getAlphabet(key){var code='_';
	switch(key){
		case 'ALEF': code='&#1575'; break; case 'BEH': code='&#1576'; break;
		case 'TEH': code='&#1578'; break; case 'THEH': code='&#1579'; break;
		case 'JEEM': code='&#1580'; break; case 'HAH': code='&#1581'; break;
		case 'KHAH': code='&#1582'; break; case 'DAL': code='&#1583'; break;
		case 'THAL': code='&#1584'; break; case 'REH': code='&#1585'; break;
		case 'ZAIN': code='&#1586'; break; case 'SEEN': code='&#1587'; break;
		case 'SHEEN': code='&#1588'; break; case 'SAD': code='&#1589'; break;
		case 'DAD': code='&#1590'; break; case 'TAH': code='&#1591'; break;
		case 'ZAH': code='&#1592'; break; case 'AIN': code='&#1593'; break;
		case 'GHAIN': code='&#1594'; break; case 'FEH': code='&#1601'; break;
		case 'QAF': code='&#1602'; break; case 'KAF': code='&#1603'; break;
		case 'LAM': code='&#1604'; break; case 'MEEM': code='&#1605'; break;
		case 'NOON': code='&#1606'; break; case 'HEH': code='&#1607'; break;
		case 'WAW': code='&#1608'; break; case 'YEH': code='&#1610'; break;
		case 'HAMZA': code='&#1569'; break;
		case 'TEH MARBUTA': code='&#1577'; break;
		case 'HAMZA': code='&#1569'; break;
		case 'ALEF WITH MADDA ABOVE': code='&#1570'; break;
		case 'ALEF WITH HAMZA ABOVE': code='&#1571'; break;
		case 'WAW WITH HAMZA ABOVE': code='&#1572'; break;
		case 'ALEF WITH HAMZA BELOW': code='&#1573'; break;
		case 'YEH WITH HAMZA ABOVE': code='&#1574'; break;
		case 'TEH MARBUTA': code='&#1577'; break;
		case 'ALEF MAKSURA': code='&#1609'; break;
	default: break;
	}
return code;
}*/
function getVowel(key){var c='_';
	switch(key){
		case 'FATHATAN':c='&#1611';break;
		case 'DAMMATAN':c='&#1612';break;
		case 'KASRATAN':c='&#1613';break;
		case 'FATHA':c='&#1614';break;
		case 'DAMMA':c='&#1615';break;
		case 'KASRA':c='&#1616';break;
		case 'SCHADDA':c='&#1617';break;
		case 'SUKUN':c='&#1618';break;
	}
	return c;
}
function getNumber(key){var c='_';
	switch(key){
		case '0':c='&#1632';break;			case '1':c='&#1633';break;
		case '2':c='&#1634';break;			case '3':c='&#1635';break;
		case '4':c='&#1636';break;			case '5':c='&#1637';break;
		case '6':c='&#1638';break;			case '7':c='&#1639';break;
		case '8':c='&#1640';break;			case '9':c='&#1641';break;
	}
	return c;
}
function getPunctuation(key){var c='undefined';
	const arrPunctuationSOURCE=['.',',',';','?',':'];
	const arrPunctuationTARGET=['.','&#1548','&#1563','&#1567',':'];
	var source=arrPunctuationSOURCE,target=arrPunctuationTARGET;
	for (var i=0;i<source.length;i++){if(key==source[i]){c=target[i];return c;}}
	// switch(key){
		// case '.':c='.';break;
		// case ',':c='&#1548';break;
		// case ';':c='&#1563';break;
		// case '?':c='&#1567';break;
		// case ':':c=':'; break;
		// default:break;
	// }
	return c;
}
function getElem(key){/*shortcut for arabic alphabet (optimized)*/
	var c='_';
	const arrAlphaSource=['A0','A1','A2','A3','A4','A5','A6','A7'];
	const arrAlphaTarget=['&#1569','&#1575','&#1570','&#1571','&#1573','&#1572','&#1609','&#1574'];
	for(var i=0;i<arrAlphaSource.length;i++){
		if(key==arrAlphaSource[i]){return(c=arrAlphaTarget[i]);}
	}
	switch(key){
		case 'B': c='&#1576';  break;
		case 'T': c='&#1578';  break; case 'T1': c='&#1577'; break; case "T'": c='&#1579'; break;
		case 'J': c='&#1580';  break; case '7': c='&#1581';  break;
		case '5': c='&#1582';  break; case 'D': c='&#1583';  break;
		case "D'": c='&#1584'; break; case 'R': c='&#1585';  break;
		case 'Z': c='&#1586';  break; case 'S': c='&#1587';  break;
		case "S'": c='&#1588'; break; case 'SX': c='&#1589'; break;
		case 'DX': c='&#1590'; break; case 'TA': c='&#1591'; break;
		case 'ZA': c='&#1592'; break; case '3': c='&#1593';  break;
		case '8': c='&#1594';  break; case 'F': c='&#1601';  break;
		case '9': c='&#1602';  break; case 'K': c='&#1603';  break;
		case 'L': c='&#1604';  break; case 'M': c='&#1605';  break;
		case 'N': c='&#1606';  break; case 'H': c='&#1607';  break;
		case 'W': c='&#1608';  break;
		case 'Y': c='&#1610';  break;
	default: break;
	}return c;}
function getSpecialCharacter(key){var c='_';
	switch(key){
		case 'SPACELABEL':c=getElem('M')+getElem('S')+getElem('A1')+getElem('F')+getElem('T1'); break;
		case 'SPACE':c='&#32;';break;
		case 'CRLABEL':c='CR';break;
		case 'CR':c='&#13;';break;
		default: break;
	}
	return c;
}
function ConvertToArabChar(key){var p='';/*convert to corresponding arabic alphabet*/
	switch(key){
		case 'a':p='ا';break;		case 'A':p='ال';break;
		case 'e':p='أ';break;
		case 'I': p='ئ';break;		case 'i': p='إ'; break;
		case 'b':p='ب';break;		case 'B':p='ب';break;	
		case 't':p='ت';break;		case 'ö':p='ة';break;	case 'T':p='ث';break;
		case 'g':p='ج';break;		case '7':p='ح';break;	case '5':p='خ';break;
		case 'c':p='ص';break;		case 'C':p='ض';break;	
		case 's':p='س';break;		case 'S':p='ش';break;	
		case 'd':p='د';break;		case 'D':p='ذ';break;	
		case 'f':p='ف';break;		case 'q':p='ق';break;	case '9':p='ق';break;
		case 'k':p='ك';break;		case 'l':p='ل';break;	case 'm':p='م';break;case 'n': p='ن'; break;
		case 'p':p='ط';break;		case 'P':p='ظ';break;	case '4':p='ظ';break;
		case 'y':p='ي';break;		case 'Y':p='ى';break;	case 'h':p='ه';break;
		case 'r':p='ر';break;		case 'R':p='ز';break;	case 'z':p='ز';break;
		case 'w':p='و';break;		case 'u':p='او';break;	case 'o':p='او';break;
		case ',':p='،';break;		case '.':p='.';break;
		case '0':p='آ';break;
		case '1':p='ء';break;
		case '2':p='ع';break;
		case '3':p='غ';break;
		case '4':p='ظ';break;
		case '5':p='خ';break;
		case '6':p='؟'; break;
		case '7':p='ح';break;
		// case '8':p='&#1567;'; break;
		case '8':p='؟'; break;
		case '9':p='ق';break;
		case '?':p='؟';break;
		default: p=key;break;
	}
	return p;
}