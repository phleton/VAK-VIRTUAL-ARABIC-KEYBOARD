/**app-components.js*/
function hide(id){get(id).style.visibility='hidden';}
function unhide(id){get(id).style.visibility='visible';}
function appComponentConsole(message){
	appConsole('->loading->COMPONENT->'+message);
}
function loadComponent_Screen(){
	appComponentConsole('SCREEN');
	setScreenSize();
}
function loadComponent_Language(){
	loadComponent_Words();
	loadComponent_Prepositions();
}
function loadComponent_Words(){appComponentConsole('words');
	gAppComponent_Words				=get(gAppID_Words);
	buildWords();
}
function loadComponent_Prepositions(){
	appComponentConsole('prepositions');
	gAppComponent_Preposition		=get(gAppID_Preposition);
	buildPreposition();/*setFocus();*/
}
function loadComponent_TextArea(){
	appComponentConsole('textarea');
	gAppComponent_TextArea			=get(gAppID_TextArea);
}
function loadComponent_Keyboard(){
	appComponentConsole('keyboard::[STARTING]');
	gAppComponent_Keyboard			=get(gAppID_Keyboard);
	buildKeyboard();
	appComponentConsole('keyboard::[LOADED]');
}
function loadComponent_Tools(){
	appComponentConsole('tools');
	gAppComponent_ToolsUp			=get(gAppID_ToolsUp);
	gAppComponent_ToolsDown			=get(gAppID_ToolsDown);
	buildTools();
	appComponentConsole('tools-search');buildToolsSearch();
	buildToolsSearch();
}
function addToComponent(id,oComponent,data){
	if(oComponent!=null){oComponent.innerHTML=data;
	}else{appConsoleError('->component:['+id+']::is::nullable!!!');}
}