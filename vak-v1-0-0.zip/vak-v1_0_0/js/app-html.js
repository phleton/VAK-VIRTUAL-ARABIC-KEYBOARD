/**vak-html.js*/
/**vak-html.js*/
const HTML_NEWLINE='<p>';
const HTML_BREAK='<br>';
const HTML_TABLE_OPENED='<table>';		const HTML_TABLE_CLOSED='</table>';
const HTML_TABLE_ROW_OPENED='<tr>';		const HTML_TABLE_ROW_CLOSED='<tr>';
const HTML_TABLE_COL_OPENED='<td>';		const HTML_TABLE_COL_CLOSED='</td>';
/**vak-html.js*/
function toButton(a,b){/*create button*/
	var btnHTML="<input type='button' value='%1' onclick='%2'>";
	btnHTML=btnHTML.replace(/%1/g,a);
	btnHTML=btnHTML.replace(/%2/g,b);
	return btnHTML;
}
function toButtonWithCSS(a,b,c){/*create button*/
	var btnHTML="<input type='button' value='%1' class='%2' onclick='%3'>";
	btnHTML=btnHTML.replace(/%1/g,a).replace(/%2/g,b);
	btnHTML=btnHTML.replace(/%3/g,c);
	return btnHTML;
}
function toCheckbox(a,b){/*create checkbox*/
	var cbxHTML="<input type='checkbox' value='%1' onclick='%2'>";
	cbxHTML=btn.replace(/%1/g,a).replace(/%2/g,b);
	return cbxHTML;
}
/**vak-html.js*/