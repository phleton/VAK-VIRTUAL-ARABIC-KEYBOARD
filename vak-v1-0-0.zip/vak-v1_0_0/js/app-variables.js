/**VARIABLES*/var gScreenWidth					=null;
/**VARIABLES*/var gScreenHeight					=null;
/**VARIABLES*/var gAppComponent_TextArea		=null;
/**VARIABLES*/var gAppComponent_Keyboard		=null;
/**VARIABLES*/var gAppComponent_Words			=null;
/**VARIABLES*/var gAppComponent_Preposition		=null;
/**VARIABLES*/var gAppComponent_ToolsUp			=null;
/**VARIABLES*/var gAppComponent_ToolsDown		=null;
