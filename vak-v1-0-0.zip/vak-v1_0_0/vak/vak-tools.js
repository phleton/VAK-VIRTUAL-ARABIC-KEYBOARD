/**vak-tools.js*/
function buildTools(tools){var appButtons='';
	const searchLabel='إبحث في ';
	const DUCKUDUCK='DuckDuckGo';
	const D=DUCKUDUCK,B='Bing',G='Google',Y='Youtube';
	const arrSearchEngines=[D,B,G,Y];
	const methodToCall='searchOnInternet';
	var methodCall='';
	var table=TABLE;
	table+=TR;
	for (var j=0;j<1;j++){table+=toButton('مسح اللوحة','clearTextArea()');}
	table+RT;
	table+=TR;
	for (var i=0;i<arrSearchEngines.length;i++){
		table+=TD;
		methodCall=methodToCall+'(%PARAM)';
		methodCall=methodCall.replace(/%PARAM/g,i);
		table+=toButton(searchLabel+arrSearchEngines[i],methodCall);
		table+=DT;
	}
	table+=RT+ELBAT;
	return table;
}
/**BUILD-TOOLS*//**BUILD-TOOLS*//**BUILD-TOOLS*//**BUILD-TOOLS*/
/**BUILD-TOOLS*//**BUILD-TOOLS*//**BUILD-TOOLS*//**BUILD-TOOLS*/
/**BUILD-TOOLS*//**BUILD-TOOLS*//**BUILD-TOOLS*//**BUILD-TOOLS*/