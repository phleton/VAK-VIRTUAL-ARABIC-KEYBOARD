﻿	/*-------------------------------
	 -     VAK Engine               -
	 -     Version: 2.0             -
	 -     Year   : October 2013    -
	 -     Author : Kais Kara       -
	 --------------------------------*/

	/**************************
	 * getting the screen size
	 **************************/
	var screenW = screen.width;
	var screenH = screen.height;
    if (_vak_tracelevel > 0) { console.log("Screen Width: " + screenW + " Height: " + screenH); };

	/*********************
     * Get Element by Id *
	 *********************/
	function vak(id) { return document.getElementById(id); }

	/***********************
     * Get Arabic Textarea *
	 ***********************/
    function _vak_getArabTextArea() { return vak(_vak_arabtextarea); }

	/***********************
     * Get Arabic Keyboard *
	 ***********************/
    function _vak_getArabKeyboard() { return vak(_vak_arabkeyboard); }

	/***********************************
     * Arabic alphabet (not optimized) *
	 ***********************************/
	/* var alphabet = new Array(
		getAlphabet("ALEF"), getAlphabet("BEH"), getAlphabet("TEH"), getAlphabet("THEH"),
		getAlphabet("JEEM"), getAlphabet("HAH"), getAlphabet("KHAH"), getAlphabet("DAL"),
		getAlphabet("THAL"), getAlphabet("REH"), getAlphabet("ZAIN"), getAlphabet("SEEN"),
		getAlphabet("SHEEN"), getAlphabet("SAD"), getAlphabet("DAD"), getAlphabet("TAH"),
		getAlphabet("ZAH"), getAlphabet("AIN"), getAlphabet("GHAIN"), getAlphabet("FEH"),
		getAlphabet("QAF"), getAlphabet("KAF"), getAlphabet("LAM"), getAlphabet("MEEM"),
		getAlphabet("NOON"), getAlphabet("HEH"), getAlphabet("WAW"), getAlphabet("YEH")
		);
	*/
	
	/*******************************
     * Arabic alphabet (optimized) *
	 *******************************/
	var alphabet = new Array(
		get("A"), get("B"), get("T"), get("T'"),
		get("J"), get("H"), get("5"), get("D"),
		get("D'"), get("R"), get("Z"), get("S"),
		get("S'"), get("SX"), get("DX"), get("TA"),
		get("ZA"), get("3"), get("8"), get("F"),
		get("9"), get("K"), get("L"), get("M"),
		get("N"), get("H"), get("W"), get("Y")
	);

	/*******************************************
     * Arabic special alphabet (not optimized) *
	 *******************************************/
	/* var specialAlphabet = new Array(
		getAlphabet("HAMZA"),
		getAlphabet("ALEF WITH MADDA ABOVE"),
		getAlphabet("ALEF WITH HAMZA ABOVE"),
		getAlphabet("ALEF WITH HAMZA BELOW"),
		getAlphabet("WAW WITH HAMZA ABOVE"),
		getAlphabet("TEH MARBUTA"),
		getAlphabet("ALEF MAKSURA"),
		getAlphabet("YEH WITH HAMZA ABOVE")
		);
	*/
	
	/***************************************
     * Arabic special alphabet (optimized) *
	 ***************************************/
	var specialAlphabet = new Array(
		get("A4"), get("A1"), get("A2"), get("A3"), get("W1"), get("T1"), get("Y1"), get("Y2")
	);

	/*********************************
     * Arabic vowels (not optimized) *
	 *********************************/
	var VOWEL = new Array("FATHA","KASRA","DAMMA","DAMMATAN","FATHATAN","KASRATAN","SCHADDA","SUKUN");

	/******************
     * Arabic1 Number *
	 ******************/
	var Numbers = new Array("0","1","2","3","4","5","6","7","8","9");

	/***************************************
     * Arabic prepositions (not optimized) *
	 ***************************************/
	/*var PREPOSITION = new Array(
		getPrep("MIN"),
		getPrep("ILEH"),
		getPrep("3AAN"),
		getPrep("3ALEH"),
		getPrep("THOMA")
	);*/
	
	/*************************************************
     * Get Arabic preposition (not really optimized) *
	 *************************************************/
	function _vak_getPrep(key) {
	var p = "_";
		switch(key) {
			case "MIN":    p = get("M")  + get("N")             ; break;
			case "ILEH":   p = get("A2") + get("L") + get("Y1") ; break;
			case "3AAN":   p = get("3")  + get("N")             ; break;
			case "3ALEH":  p = get("3")  + get("L") + get("Y1") ; break;
			case "FIH":    p = get("F")  + get("Y")             ; break;
			case "THOMA":  p = get("T'") + get("M")             ; break;
			case "7ATA":   p = get("7")  + get("T") + get("Y1") ; break;
			case "ME3A":   p = get("M")  + get("3")             ; break;
			case "TA7TA":  p = get("T")  + get("7") + get("T")  ; break;
			case "FAW9A":  p = get("F")  + get("W") + get("9")  ; break;
			case "THEDA":  p = get("DX") + get("D")             ; break;
			case "3ABRA":  p = get("3")  + get("B") + get("R")  ; break;
			case "THLIKA": p = get("D'") + get("L") + get("K")  ; break;
			case "BA3DA":  p = get("B")  + get("3") + get("D")  ; break;
			case "NAHWA":  p = get("N")  + get("7") + get("W")  ; break;
			case "KYFA":   p = get("K")  + get("Y") + get("F")  ; break;
		default: break;
		}
	return p;
	}

    /***************************************
     * Get Arabic alphabet (not optimized) *
	 ***************************************/
	/*function getAlphabet(key) {
	var code = "_";
		switch(key) {
			case "ALEF"  : code = "&#1575"; break; 		case "BEH"  : code = "&#1576"; break;
			case "TEH"   : code = "&#1578"; break; 		case "THEH" : code = "&#1579"; break;
			case "JEEM"  : code = "&#1580"; break; 		case "HAH"  : code = "&#1581"; break;
			case "KHAH"  : code = "&#1582"; break; 		case "DAL"  : code = "&#1583"; break;
			case "THAL"  : code = "&#1584"; break; 		case "REH"  : code = "&#1585"; break;
			case "ZAIN"  : code = "&#1586"; break; 		case "SEEN" : code = "&#1587"; break;
			case "SHEEN" : code = "&#1588"; break; 		case "SAD"  : code = "&#1589"; break;
			case "DAD"   : code = "&#1590"; break; 		case "TAH"  : code = "&#1591"; break;
			case "ZAH"   : code = "&#1592"; break; 		case "AIN"  : code = "&#1593"; break;
			case "GHAIN" : code = "&#1594"; break; 		case "FEH"  : code = "&#1601"; break;
			case "QAF"   : code = "&#1602"; break; 		case "KAF"  : code = "&#1603"; break;
			case "LAM"   : code = "&#1604"; break; 		case "MEEM" : code = "&#1605"; break;
			case "NOON"  : code = "&#1606"; break; 		case "HEH"  : code = "&#1607"; break;
			case "WAW"   : code = "&#1608"; break; 		case "YEH"  : code = "&#1610"; break;
			
			case "HAMZA"                 : code = "&#1569"; break;
			case "TEH MARBUTA"           : code = "&#1577"; break;
			case "ALEF WITH MADDA ABOVE" : code = "&#1570"; break;
			case "ALEF WITH HAMZA ABOVE" : code = "&#1571"; break;
			case "WAW WITH HAMZA ABOVE"  : code = "&#1572"; break;
			case "ALEF WITH HAMZA BELOW" : code = "&#1573"; break;
			case "YEH WITH HAMZA ABOVE"  : code = "&#1574"; break;
			case "TEH MARBUTA"           : code = "&#1577"; break;
			case "ALEF MAKSURA"          : code = "&#1609"; break;
			
		default: break;
		}
	return code;
	}*/
	
	/********************************************
     * shortcut for arabic alphabet (optimized) *
	 ********************************************/
	function get(key) {
	var c = "_";
		switch(key) {
			case "A"  : c = "&#1575"; break; 	case "A1" : c = "&#1571"; break; 	case "A2" : c = "&#1573"; break;
			case "A3" : c = "&#1570"; break; 	case "A4" : c = "&#1569"; break;
			case "B"  : c = "&#1576"; break;
			case "T"  : c = "&#1578"; break; 	case "T1" : c = "&#1577"; break; 	case "T'" : c = "&#1579"; break;
			case "J"  : c = "&#1580"; break; 	case "7"  : c = "&#1581"; break;
			case "5"  : c = "&#1582"; break; 	case "D"  : c = "&#1583"; break;
			case "D'" : c = "&#1584"; break; 	case "R"  : c = "&#1585"; break;
			case "Z"  : c = "&#1586"; break; 	case "S"  : c = "&#1587"; break;
			case "S'" : c = "&#1588"; break; 	case "SX" : c = "&#1589"; break;
			case "DX" : c = "&#1590"; break; 	case "TA" : c = "&#1591"; break;
			case "ZA" : c = "&#1592"; break; 	case "3"  : c = "&#1593"; break;
			case "8"  : c = "&#1594"; break; 	case "F"  : c = "&#1601"; break;
			case "9"  : c = "&#1602"; break; 	case "K"  : c = "&#1603"; break;
			case "L"  : c = "&#1604"; break; 	case "M"  : c = "&#1605"; break;
			case "N"  : c = "&#1606"; break; 	case "H"  : c = "&#1607"; break;
			case "W"  : c = "&#1608"; break; 	case "W1" : c = "&#1572"; break;
			case "Y"  : c = "&#1610"; break; 	case "Y1" : c = "&#1609"; break; 	case "Y2" : c = "&#1574"; break;
		default: break;
		}
	return c;
	}
	
	/*************************
	 * Getting Arabic Vowels *
	 *************************/
	function _vak_getArabicVowel(key) {
		var vowel = "_";
			switch(key) {
				case "FATHATAN": vowel = "&#1611"; break;
				case "DAMMATAN": vowel = "&#1612"; break;
				case "KASRATAN": vowel = "&#1613"; break;
				case "FATHA"   : vowel = "&#1614"; break;
				case "DAMMA"   : vowel = "&#1615"; break;
				case "KASRA"   : vowel = "&#1616"; break;
				case "SCHADDA" : vowel = "&#1617"; break;
				case "SUKUN"   : vowel = "&#1618"; break;
			}
		return vowel;
	}
	
	/*****************************
	 * Converting Arabic Numbers *
	 *****************************/
	function _vak_convertToArabicNumber(key) {
		var num = "_";
			switch(key) {
				case "0": num = "&#1632"; break;
				case "1": num = "&#1633"; break;
				case "2": num = "&#1634"; break;
				case "3": num = "&#1635"; break;
				case "4": num = "&#1636"; break;
				case "5": num = "&#1637"; break;
				case "6": num = "&#1638"; break;
				case "7": num = "&#1639"; break;
				case "8": num = "&#1640"; break;
				case "9": num = "&#1641"; break;
			}
		return num;
	}

	/***************
	 * Punctuation *
	 ***************/
	function _vak_getPunctuation(key) {
		var punct = "_";
			switch(key) {
				case ".": punct = "."; break;
				case ",": punct = "&#1548"; break;
				case ";": punct = "&#1563"; break;
				case "?": punct = "&#1567"; break;
				case ":": punct = ":"; break;
			default: break;
			}
		return punct;
	}
	
	/***************
	 * Additional  *
	 ***************/
	function _vak_getOthers(key) {
	var others = "_";
		switch(key) {
			case "SPACELABEL" : others = get("M") + get("S") + get("A") + get("F") + get("T1"); break;
			case "SPACE"      : others = "&#32;" 						  ; break;
			case "CRLABEL"    : others = "CR"    						  ; break;
			case "CR"         : others = "&#13;" 						  ; break;
		default: break;
		}
	return others;
	}

	/*******************
     * Write character *
	 *******************/
	function _vak_writeCharacter(character) {
		var area = _vak_getArabTextArea();
		area.focus();
		var _selB = area.selectionStart;
		var _selE = area.selectionEnd;
		area.value = area.value.substr(0,_selB) + character + area.value.substr(_selE);
		var CursorNextPosition = _selB+character.length;
		area.setSelectionRange(CursorNextPosition, CursorNextPosition);
		area.focus();
	}

	/********************
	 * Delete character *
	 ********************/
	function _vak_deleteCharacter() {
		var area = _vak_getArabTextArea();
		var CursorNextPosition;
		area.focus();
		var _selB = area.selectionStart;
		var _selE = area.selectionEnd;
		
		if (_selB==_selE) {
			area.value = area.value.substr(0,_selB-1) + area.value.substr(_selE);
			CursorNextPosition = _selB-1;
		}
		else {
			area.value = area.value.substr(0,_selB) + area.value.substr(_selE);
			CursorNextPosition = _selB;
		}
		area.setSelectionRange(CursorNextPosition, CursorNextPosition);
		area.focus();
	}

	/*************************************************
     * Write word and append whitespace if necessary *
	 *************************************************/
	function _vak_writeWord(word) {
		var area = _vak_getArabTextArea();
		area.focus();
		var _selB = area.selectionStart;
		var _selE = area.selectionEnd;
		var _prevW = area.value.substr(_selB-1, 1);
		var _forwW = area.value.substr(_selE, 1);
		var _appendW = "";
		if ((_prevW!=" ")&&(_selB>0)) _appendW = " "
		_appendW += word;
		if (_forwW!=" ") _appendW += " ";
		// console.log('*' + _appendW + '*');
		area.value = area.value.substr(0,_selB) + _appendW + area.value.substr(_selE);
		var CursorNextPosition = _selB+_appendW.length;
		area.setSelectionRange(CursorNextPosition, CursorNextPosition);
		area.focus();
	}

	/***************************************
     * Clear written text in the text area *
	 ***************************************/
	function _vak_clearArabText() {
	  var area = _vak_getArabTextArea();
      area.value = "";
      area.focus();
    }

	/*****************
	 * create button *
	 *****************/
	function _vak_mapToButton(a, b) {
	var _input = "<input type='button' value='%1' onclick='%2'>";
		return (_input.replace(/%1/g, a)).replace(/%2/g, b);
	}
