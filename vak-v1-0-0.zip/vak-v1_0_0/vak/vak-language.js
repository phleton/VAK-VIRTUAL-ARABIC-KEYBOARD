/**vak-language.js*/
/**vak-language.js*/
/**vak-language.js*/
/**vak-language.js*/
/**vak-language.js*/