/**vak-functions.js*/
/**vak-functions.js*/
function parseCssToInt(cssStr){var val=parseInt(cssStr.substring(0,3));return val;}
/**vak-functions.js*/
/**vak-functions.js*/