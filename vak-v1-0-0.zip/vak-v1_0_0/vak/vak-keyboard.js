/*****************/
/* Buid keyboard */
/*****************/
var arrKeyboardRow01=['J','7','5','H','3','8','F','9','SX','DX'];
var arrKeyboardRow02=['K','M','N','T','A','L','B','Y','S',"S'"];
var arrKeyboardRow03=["T'",'T1','W','R','Z','D',"D'",'TA','ZA'];
var arrKeyboardRow04=['A2','A3','A1','W1','Y1','Y2','A4'];
var arrKeyboardRow05=[':',';','?'];
var arrKeyboardRow06=new Array('.',',');
/******************************************
*Helping function to build Keyboard Row *
 ******************************************/
function mapToKeyboardRow(arr,a){var col='',container='';
	var tagElem="<input type='button' value='%PARM' class='_druckZeichen' onclick='writeCharacter(\"%PARM\")'>";
	for(var i=(arr.length-1);i>=0;i--){col=tagElem;col=col.replace(/%PARM/g,a(arr[i]));container+=col;}
	return container;
}
/*******************************
* building the arabic keyboard *
********************************/
function buildKeyboard(){
	var keyboardREST=new Array('SPACE');
	var keyboardLABEL=new Array('SPACELABEL');
	var tagElem="<input type='button' value='%PARM' class='_druckZeichen' onclick='writeCharacter(\"%PARM\")'>";
	const deleteButton="<input type='button' value='مسح' class='_druckZeichen' onclick='deleteCharacter()'>";
	var btnKey="<input type='button' value='%PARM1' class='_backspace' onclick='writeCharacter(\"%PARM2\")'>";
	var table=null,tableRow=null,tableCol=null;
	table+=mapToKeyboardRow(VOWEL,getVowel)+P;
	table+=mapToKeyboardRow(arrKeyboardRow01,get)+BR;
	table+=mapToKeyboardRow(arrKeyboardRow02,get)+BR;
	table+=mapToKeyboardRow(arrKeyboardRow03,get)+BR;
	table+=mapToKeyboardRow(arrKeyboardRow04,get)+BR;
	table+=deleteButton+mapToKeyboardRow(arrKeyboardRow05,getPunctuation);
	for (var i=(keyboardREST.length-1);i>=0;i--) {
		tableRow=btnKey.replace(/%PARM1/g,getOthers(keyboardLABEL[i])).replace(/%PARM2/g,getOthers(keyboardREST[i]));
		table+=tableRow;
	}
	table+=BR;
	table+=mapToKeyboardRow(arrKeyboardRow06,getPunctuation)+BR;
	table+=mapToKeyboardRow(Numbers,getNumber)+P;
	return table;
}
function buildKeyCombination(){/*showing the helping key combination in order to display arabic characters*/
	var table="<table border='1' id='_keyCmbTab' class='_keyCmbTab'>";
	const DRUCKZEICHEN="<input type='button' value='%PARM' class='DruckZeichen'>";
	var tagElem='';
	for (var i=0;i<arrKeyboardSource.length;i++){
		tagElem=DRUCKZEICHEN.replace(/%PARM/g,arrKeyboardSource[i]);
		table+=TR;table+=TD+tagElem+DT;
		table+=TD+arrKeyboardTarget[i]+DT;table+=RT;
	}table+=ELBAT
	// console.info(table);
	/*console.info(table);*/return table;
}