/**vak-background.js*/
/**vak-background.js*/
/**vak-background.js*/
/**vak-background.js*/
var arrBgImages=arrBackgroundImages;
function buildBackground(){
	buildBackgroundWebsite();
}
function buildBackgroundWebsite(){/*website->background->image*/
	var max=arrBgImages.length,min=0;
	var gen=Math.floor(Math.random()*(max-min+1))+min;
	setBackground(gen);
	if(gen<(max-1))gen+=1;else{gen=0;}
	get(idAppBackgroundImageID).value=arrBgImages[gen];
}
function showBackground(){return showHideBackground(true);}
function hideBackground(){return showHideBackground(false);}
function showHideBackground(showFlag){/*function->hide->websiteBackground*/
	var container123=get(idAppMainContainerID);
	var container345=get(idAppBtnSheeID);
	if(container123==null){return;}
	if(showFlag){
		container345.value='hide';
		container123.style.opacity=0.85;
	}
	if(!showFlag){
		container345.value='show';
		container123.style.opacity=1.0;
	}
}
function setBackground(id){/*set background image of the website*/
	var picURL='url(pics/'+arrBgImages[id]+'.jpg)';
	document.body.style.backgroundImage=picURL;
}
function switchBackground(){/*function->switch->websiteBackground*/
	var nodeBgImage=get(idAppBackgroundImageID).value;
	/*rotate->backgroundImage->towebsite->return->next->picID*/
	var id=rotateBackground(nodeBgImage);
	/*assign->next->imageName->toscreen*/nodeBgImage.value=arrBgImages[id];
}
function rotateBackground(parImage){/*rotate->websiteBackground*/
	var pic=parImage,picURL='',id=0;
	for(var i=0;i<arrBgImages.length;i++){if(arrBgImages[i].match(pic))id=i;}
	setBackground(id);
	if(id<(arrBgImages.length-1))id+=1;else{id=0;}
	/*returnNextID*/return id;
}
/**vak-background.js*/
/**vak-background.js*/
/**vak-background.js*/
/**vak-background.js*/