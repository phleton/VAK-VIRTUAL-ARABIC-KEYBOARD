﻿/**vak-engine-1.1.js*/
/**vak-engine-1.1.js*/
/**vak-engine-1.1.js*/
/**vak-engine-1.1.js*/
/*-------------------------------
-    VAK Engine               -
-    Version: 1.1             -
-    Year   : September 2013  -
-    Author : Kais Kara       -
 --------------------------------*/
/**dos.js*/
/**dos.js*/
/**dos.js*/
/*Get Element by Id*/function get(id){return document.getElementById(id);}
/**dos.js*/
/**dos.js*/
/**dos.js*/
/*****************/
/* create button */
/*****************/function toButton(a,b){var plainButton="<input type='button' value='%1' onclick='%2'>";return (plainButton.replace(/%1/g,a)).replace(/%2/g,b);}
/**vak-engine-1.1.js*/
/**vak-engine-1.1.js*/
/**vak-engine-1.1.js*/
/**vak-engine-1.1.js*/