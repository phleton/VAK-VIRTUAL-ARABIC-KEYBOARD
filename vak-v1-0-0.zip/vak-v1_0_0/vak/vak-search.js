/**vak-search.js*/
/**vak-search.js*/
/**********************
*Searching function *
 *****************************************************************************************/
	function searchOnInternet(id){const HTTP_WWW='http://www.';
		var url='',query=get(gAppTextArea).value;
		switch(id){
		  /*search on duckduckgo*/case 1 :url='https://duckduckgo.com/?q='						+query;break;
		  /*search on bing*_____*/case 2 :url='http://www.bing.com/search?q='					+query;break;
		  /*search on youtube___*/case 3 :url='http://www.youtube.com/results?search_query='	+query;break;
		  /*search on Google____*/case 4 :url='http://www.google.com/#hl=ar&output=search&q='	+query;	break;
		  /**default:google*____*/default:url='http://www.google.com/#hl=ar&output=search&q='	+query;break;
		}window.open(url);
	}
/*                                                                                       */
/*****************************************************************************************/
/**vak-search.js*/
/**vak-search.js*/