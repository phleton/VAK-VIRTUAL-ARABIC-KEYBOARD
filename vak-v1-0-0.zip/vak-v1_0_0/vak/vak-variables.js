/**vak-variables.js*/
/**vak-variables.js*/
var gAppMainContainer=null;
var AppBGImages=null;
var gAppBtnShee=null;
var gAppTextArea=null;
var gAppKeyboard=null;
var gAppKeyCombination=null;
var gAppTools=null;
var gAppWords=null;
var gAppPrepositions=null;
/**vak-variables.js*/
/**vak-variables.js*/
var isInfoSet=false;
/**vak-variables.js*/
/**vak-variables.js*/
/**vak-variables.js*/
/**vak-variables.js*/
/**vak-variables.js*/