/**vak-load.js*/
/**LOAD-APP*/
/**LOAD-APP*/
/**LOAD-APP*/
/**LOAD-APP*/
function loadApp(){
	/**LOAD-APP*/
	/**LOAD-APP*/
	loadScreen();
	loadLogo();
	loadBackground();
	if(!checkBrowser()){return false;}
	/**LOAD-APP*/
	loadTools();
	/**LOAD-APP*/
	loadKeyboard();
	/**LOAD-APP*/
	loadLanguage();
	/**LOAD-APP*/
	/**LOAD-APP*/
	/**LOAD-APP*/
	/**LOAD-APP*/
}
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
function loadScreen(){getScreenSize();}
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
function loadLogo(){var logo=get(idAppLogoID);if(logo!=null){logo.src=APP_LOGO;}}
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
function checkBrowser(){
	if(navigator.appName.indexOf("Internet Explorer")!=-1){get('appConsoleInfo').innerHTML="<h3>Currently no support for Internet Explorer!</h3><p/>"+ "Please use Google Chrome,or Mozilla,Opera,Safari.";
	return false;}else{return true;}
}
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
function loadBackground(){
	buildBackground();
	btnSheefamao=get(idAppBtnSheeID);
	if(btnSheefamao!=null){btnSheefamao.value='hide';
		btnSheefamao.onclick=function(){showHideBackground(false);}
		showHideBackground(true);
	}
}
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
/**LOAD-APP*//**LOAD-APP*//**LOAD-APP*//**LOAD-APP*/
/**load-language*/
/**load-language*/
/**load-language*/
/**load-language*/
function loadLanguage(){var sectionWORDS=null
	sectionWORDS=get(idAppPrepositionsID);
	if(sectionWORDS!=null){
		containerForWords=buildWords(gAppWords,arrQuickWords);
		sectionWORDS.innerHTML=containerForWords;
	}else{tools.innerHTML=NOT_AVAILABLE;}
	sectionWORDS=get(idAppWordsID);
	if(sectionWORDS!=null){
		containerForWords=buildPreposition(gAppPrepositions,arrPrepositions);
		sectionWORDS.innerHTML=containerForWords;
	}else{tools.innerHTML=NOT_AVAILABLE;}
	loadKeyCombination();
	setFocus_TextArea();
}
/**load-tools*/
/**load-tools*/
/**load-tools*/
function loadTools(){var tools=null,plainNode=null;
	tools=get(idAppToolsID);
	if(tools!=null){gAppTools=tools;
		plainNode=buildTools(tools);
		tools.innerHTML=plainNode;
	}
	else{tools.innerHTML=NOT_AVAILABLE;}
}
/**loadKEyboard*/
/**loadKEyboard*/
/**loadKEyboard*/
function loadKeyboard(){var plainNode=null,tastatur=null;
	tastatur=get(idAppKeyboardID);
	if(tastatur!=null){gAppKeyboard=tastatur;
		plainNode=buildKeyboard();
		tastatur.innerHTML=plainNode;
	}
	else{tastatur.innerHTML=NOT_AVAILABLE;}
}
/**loadKeyCombination*/
/**loadKeyCombination*/
/**loadKeyCombination*/
function loadKeyCombination(){var plainNode=null,tastatur=null;
	tastatur=get(idKeyCombinationID);
	if(tastatur!=null){gAppKeyCombination=tastatur;
		plainNode=buildKeyCombination();
		tastatur.innerHTML=plainNode;
	}
	else{tastatur.innerHTML=NOT_AVAILABLE;}
}
/**EXAMPLE*/
/**EXAMPLE*/
/**EXAMPLE*/
// function aoo(iod,noode){var plainNode=null,tastatur=null;
	// tastatur=get(iod);
	// if(tastatur!=null){gAppKeyboard=tastatur;
		// tastatur.innerHTML=noode;
	// }
	// else{
		// tastatur.innerHTML=NOT_AVAILABLE;
	// }
// }