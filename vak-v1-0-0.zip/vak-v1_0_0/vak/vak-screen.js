/**vak-screen.js*/
/**vak-screen.js*/
/**vak-screen.js*/
/*getting the screen size*/
var screenWidth=0;var screenHeight=0;
function getScreenSize(){
	// screenWidth=screen.width;screenHeight=screen.height;
	// appInfo('Screen Width/Height: ['+screenWidth+'/'+screenHeight+']'+PIXEL);
	appInfo('Screen Width/Height: ['+SCREEN_WIDTH+'/'+SCREEN_HEIGHT+']'+PIXEL);
}
/**vak-screen.js*/
/**vak-screen.js*/
/**vak-screen.js*/