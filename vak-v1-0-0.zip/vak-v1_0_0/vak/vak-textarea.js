/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**************************************
* This function will be triggered,    *
* whenever a key is pressed           *
 **************************************/
function keypressed(e){var keyCode=(e.which)?e.which:e.keyCode/*bug->fixing->firefox::21.09.2013*/
	var pressChar=String.fromCharCode(keyCode);var arabChar=ConvertToArabChar(pressChar);
	e.preventDefault();if(arabChar!= pressChar)writeCharacter(arabChar);
	else{arabChar=ConvertToArabWord(pressChar);if(arabChar!=pressChar)writeWord(arabChar);else writeCharacter(arabChar);}
}
/*textarea->setFocus_*/
/*textarea->setFocus_*/
/*textarea->setFocus_*/
function setFocus_TextArea(){var appArea=null;
	appArea=get(idAppTextAreaID);
	if(appArea!=null){appArea.focus();/*document.getElementById('_textarea').focus();*/
	}else{console.info('focus cannot be set!');}
}
/*textarea->setFocus_*/
/*textarea->setFocus_*/
/*textarea->setFocus_*/
/*textarea->ClearText*/
/*textarea->ClearText*/
/*textarea->ClearText*/
function clearTextArea(){var appArea123=get(idAppTextAreaID);
	if(appArea123==null){appError('cannot->clear->text!');return;}
	appArea123.value='';
	setFocus_TextArea()
}
/*textarea->ClearText*/
/*textarea->ClearText*/
/*textarea->ClearText*/
/*******************
 * Write character *
 *******************/
function writeCharacter(character){var appArea=get(idAppTextAreaID);
	if(appArea==null){console.error('cannot->write->character!');return;}
	setFocus_TextArea();
	var cursorSelBegin=appArea.selectionStart;
	var cursorSelEnd=appArea.selectionEnd;
	appArea.value=appArea.value.substr(0,cursorSelBegin)+character+appArea.value.substr(cursorSelEnd);
	var cursorNextPos=cursorSelBegin+character.length;
	appArea.setSelectionRange(cursorNextPos,cursorNextPos);
	setFocus_TextArea();
}
/********************
 * Delete character *
 ********************/
function deleteCharacter(){var appArea=get(gAppTextArea),cursorNextPos=-1;
	setFocus_TextArea();
	var cursorSelBegin=appArea.selectionStart,cursorSelEnd=appArea.selectionEnd;
	if(cursorSelBegin==cursorSelEnd){appArea.value=appArea.value.substr(0,cursorSelBegin-1)+appArea.value.substr(cursorSelEnd);cursorNextPos=cursorSelBegin-1;}
	else{appArea.value=appArea.value.substr(0,cursorSelBegin)+appArea.value.substr(cursorSelEnd);cursorNextPos=cursorSelBegin;}
	appArea.setSelectionRange(cursorNextPos,cursorNextPos);
	setFocus_TextArea();
}
/*************************************************
	*Write word and append whitespace if necessary *
 *************************************************/
function writeWord(word){var appArea=null;
	var cursorSelBegin=null,cursorSelEnd=null;
	var prevWord=null,pushedWord=null;
	var cursorNextPos=null;
	appArea=get(gAppTextArea);if(appArea!=null){setFocus_TextArea();}else{window.alert('->the textarea is nullable!')}
	if(appArea==null){return;}
	cursorSelBegin=appArea.selectionStart;
	cursorSelEnd=appArea.selectionEnd;
	prevWord=appArea.value.substr(cursorSelBegin-1,1),forWord=appArea.value.substr(cursorSelEnd,1);
	pushedWord='';
	if((prevWord!=' ')&&(cursorSelBegin>0)){pushedWord=' ';}
	pushedWord+=word;
	if(forWord!=' '){pushedWord+=' ';}/*console.log('*'+pushedWord+'*');*/
	appArea.value=appArea.value.substr(0,cursorSelBegin)+pushedWord+appArea.value.substr(cursorSelEnd);
	cursorNextPos=cursorSelBegin+pushedWord.length;
	appArea.setSelectionRange(cursorNextPos,cursorNextPos);
	setFocus_TextArea();
}
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/
/**vak-textarea.js*/