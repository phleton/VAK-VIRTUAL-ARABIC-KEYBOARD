/**vak-menu.js*/
/**vak-menu.js*/
/**vak-menu.js*/
/******************//*showing the menu*/function showMenu(area){var _submenu=getElem(area);if (_submenu!=null)_submenu.style.display='block';}
/* Menu functions *//*hidding the menu*/function hideMenu(area){var _submenu=getElem(area);if(_submenu!=null)_submenu.style.display='none';}
/******************/
/**vak-menu.js*/
/**vak-menu.js*/
/**vak-menu.js*/