/**vak-language-arabic.js*/
/**vak-language-arabic.js*/
/**vak-language-arabic.js*/
/*arabic words*/
/*key combination for arabic letters*/
var arrQuickWords=new Array('أنا','أنتَ','أنتِ','هذا','هو','هي','نحن','هم');
var arrPrepositions=new Array('MIN','ILEH','3AAN','3ALEH','FIH','THOMA','7ATA','ME3A','FAW9A','TA7TA',
'THEDA','3ABRA','THLIKA','BA3DA','NAHWA','KYFA');
var arrKeyboardSource=new Array('a','A','b or B','t','T',
'g','7','5','d','D',
'r','R or z','s','S','c','C',
'p','4','3','','f','q or 9',
'k','l','m','n','h','w','y');
var arrKeyboardTarget=new Array('ا','أ','ب','ت','ث',
'ج','ح','خ','د','ذ',
'ر','ز','س','ش','ص','ض',
'ط','ظ','ع','غ','ف','ق',
'ك','ل','م','ن','ه','و','ي');
/***********************************
 * Arabic alphabet (not optimized) *
 ***********************************/
/* var alphabet=new Array(
	getAlphabet("ALEF"),getAlphabet("BEH"),getAlphabet("TEH"),getAlphabet("THEH"),
	getAlphabet("JEEM"),getAlphabet("HAH"),getAlphabet("KHAH"),getAlphabet("DAL"),
	getAlphabet("THAL"),getAlphabet("REH"),getAlphabet("ZAIN"),getAlphabet("SEEN"),
	getAlphabet("SHEEN"),getAlphabet("SAD"),getAlphabet("DAD"),getAlphabet("TAH"),
	getAlphabet("ZAH"),getAlphabet("AIN"),getAlphabet("GHAIN"),getAlphabet("FEH"),
	getAlphabet("QAF"),getAlphabet("KAF"),getAlphabet("LAM"),getAlphabet("MEEM"),
	getAlphabet("NOON"),getAlphabet("HEH"),getAlphabet("WAW"),getAlphabet("YEH")
	);
*/
/*******************************
 * Arabic alphabet (optimized) *
 *******************************/
var alphabet=new Array(getElem("A"),getElem("B"),getElem("T"),getElem("T'"),
getElem("J"),getElem("H"),getElem("5"),getElem("D"),
getElem("D'"),getElem("R"),getElem("Z"),getElem("S"),
getElem("S'"),getElem("SX"),getElem("DX"),getElem("TA"),
getElem("ZA"),getElem("3"),getElem("8"),getElem("F"),
getElem("9"),getElem("K"),getElem("L"),getElem("M"),
getElem("N"),getElem("H"),getElem("W"),getElem("Y")
);
/*******************************************
 * Arabic special alphabet (not optimized) *
 *******************************************/
/* var specialAlphabet=new Array(
	getAlphabet("HAMZA"),
	getAlphabet("ALEF WITH MADDA ABOVE"),
	getAlphabet("ALEF WITH HAMZA ABOVE"),
	getAlphabet("ALEF WITH HAMZA BELOW"),
	getAlphabet("WAW WITH HAMZA ABOVE"),
	getAlphabet("TEH MARBUTA"),
	getAlphabet("ALEF MAKSURA"),
	getAlphabet("YEH WITH HAMZA ABOVE")
	);
*/
/***************************************
 * Arabic special alphabet (optimized) *
 ***************************************/
var specialAlphabet=new Array(getElem("A4"),getElem("A1"),getElem("A2"),getElem("A3"),getElem("W1"),getElem("T1"),getElem("Y1"),getElem("Y2")
);
/*********************************
 * Arabic vowels (not optimized) *
 *********************************/
var VOWEL=new Array("FATHA","KASRA","DAMMA","DAMMATAN","FATHATAN","KASRATAN","SCHADDA","SUKUN");
/******************
 * Arabic1 Number *
 ******************/
var Numbers=new Array("0","1","2","3","4","5","6","7","8","9");
/***************************************
 * Arabic prepositions (not optimized) *
 ***************************************/
/*var PREPOSITION=new Array(
	getPrep("MIN"),
	getPrep("ILEH"),
	getPrep("3AAN"),
	getPrep("3ALEH"),
	getPrep("THOMA")
);*/
/*************************************************
	*Get Arabic preposition (not really optimized) *
 *************************************************/
function getPrep(key) {
var p="_";
	switch(key) {
		case "MIN":    p=getElem("M") +getElem("N")             ;break;
		case "ILEH":   p=getElem("A2")+getElem("L")+getElem("Y1") ;break;
		case "3AAN":   p=getElem("3") +getElem("N")             ;break;
		case "3ALEH":  p=getElem("3") +getElem("L")+getElem("Y1") ;break;
		case "FIH":    p=getElem("F") +getElem("Y")             ;break;
		case "THOMA":  p=getElem("T'")+getElem("M")             ;break;
		case "7ATA":   p=getElem("7") +getElem("T")+getElem("Y1") ;break;
		case "ME3A":   p=getElem("M") +getElem("3")             ;break;
		case "TA7TA":  p=getElem("T") +getElem("7")+getElem("T")  ;break;
		case "FAW9A":  p=getElem("F") +getElem("W")+getElem("9")  ;break;
		case "THEDA":  p=getElem("DX")+getElem("D")             ;break;
		case "3ABRA":  p=getElem("3") +getElem("B")+getElem("R")  ;break;
		case "THLIKA": p=getElem("D'")+getElem("L")+getElem("K")  ;break;
		case "BA3DA":  p=getElem("B") +getElem("3")+getElem("D")  ;break;
		case "NAHWA":  p=getElem("N") +getElem("7")+getElem("W")  ;break;
		case "KYFA":   p=getElem("K") +getElem("Y")+getElem("F")  ;break;
	default: break;
	}
return p;
}
	/***************************************
	*Get Arabic alphabet (not optimized) *
 ***************************************/
/*function getAlphabet(key) {
var code="_";
	switch(key) {
		case "ALEF"  : code="&#1575";break;		case "BEH"  : code="&#1576";break;
		case "TEH"   : code="&#1578";break;		case "THEH" : code="&#1579";break;
		case "JEEM"  : code="&#1580";break;		case "HAH"  : code="&#1581";break;
		case "KHAH"  : code="&#1582";break;		case "DAL"  : code="&#1583";break;
		case "THAL"  : code="&#1584";break;		case "REH"  : code="&#1585";break;
		case "ZAIN"  : code="&#1586";break;		case "SEEN" : code="&#1587";break;
		case "SHEEN" : code="&#1588";break;		case "SAD"  : code="&#1589";break;
		case "DAD"   : code="&#1590";break;		case "TAH"  : code="&#1591";break;
		case "ZAH"   : code="&#1592";break;		case "AIN"  : code="&#1593";break;
		case "GHAIN" : code="&#1594";break;		case "FEH"  : code="&#1601";break;
		case "QAF"   : code="&#1602";break;		case "KAF"  : code="&#1603";break;
		case "LAM"   : code="&#1604";break;		case "MEEM" : code="&#1605";break;
		case "NOON"  : code="&#1606";break;		case "HEH"  : code="&#1607";break;
		case "WAW"   : code="&#1608";break;		case "YEH"  : code="&#1610";break;
		case "HAMZA" : code="&#1569";break;
		case "TEH MARBUTA"           : code="&#1577";break;
		case "ALEF WITH MADDA ABOVE" : code="&#1570";break;
		case "ALEF WITH HAMZA ABOVE" : code="&#1571";break;
		case "WAW WITH HAMZA ABOVE"  : code="&#1572";break;
		case "ALEF WITH HAMZA BELOW" : code="&#1573";break;
		case "YEH WITH HAMZA ABOVE"  : code="&#1574";break;
		case "TEH MARBUTA"           : code="&#1577";break;
		case "ALEF MAKSURA"          : code="&#1609";break;
	default: break;
	}
return code;
}*/
/********************************************
	*shortcut for arabic alphabet (optimized) *
 ********************************************/
function getElem(key) {
var c="_";
	switch(key) {
		case "A"  : c="&#1575";break;	case "A1" : c="&#1571";break;	case "A2" : c="&#1573";break;
		case "A3" : c="&#1570";break;	case "A4" : c="&#1569";break;
		case "B"  : c="&#1576";break;
		case "T"  : c="&#1578";break;	case "T1" : c="&#1577";break;	case "T'" : c="&#1579";break;
		case "J"  : c="&#1580";break;	case "7"  : c="&#1581";break;
		case "5"  : c="&#1582";break;	case "D"  : c="&#1583";break;
		case "D'" : c="&#1584";break;	case "R"  : c="&#1585";break;
		case "Z"  : c="&#1586";break;	case "S"  : c="&#1587";break;
		case "S'" : c="&#1588";break;	case "SX" : c="&#1589";break;
		case "DX" : c="&#1590";break;	case "TA" : c="&#1591";break;
		case "ZA" : c="&#1592";break;	case "3"  : c="&#1593";break;
		case "8"  : c="&#1594";break;	case "F"  : c="&#1601";break;
		case "9"  : c="&#1602";break;	case "K"  : c="&#1603";break;
		case "L"  : c="&#1604";break;	case "M"  : c="&#1605";break;
		case "N"  : c="&#1606";break;	case "H"  : c="&#1607";break;
		case "W"  : c="&#1608";break;	case "W1" : c="&#1572";break;
		case "Y"  : c="&#1610";break;	case "Y1" : c="&#1609";break;	case "Y2" : c="&#1574";break;
	default: break;
	}
return c;
}
/*************************
*Getting Arabic Vowels *
 *************************/
function getVowel(key) {
	var vowel="_";
		switch(key) {
			case "FATHATAN": vowel="&#1611";break;
			case "DAMMATAN": vowel="&#1612";break;
			case "KASRATAN": vowel="&#1613";break;
			case "FATHA"   : vowel="&#1614";break;
			case "DAMMA"   : vowel="&#1615";break;
			case "KASRA"   : vowel="&#1616";break;
			case "SCHADDA" : vowel="&#1617";break;
			case "SUKUN"   : vowel="&#1618";break;
		}
	return vowel;
}
/*****************************
*Converting Arabic Numbers *
 *****************************/
function getNumber(key) {
	var num="_";
		switch(key) {
			case "0": num="&#1632";break;
			case "1": num="&#1633";break;
			case "2": num="&#1634";break;
			case "3": num="&#1635";break;
			case "4": num="&#1636";break;
			case "5": num="&#1637";break;
			case "6": num="&#1638";break;
			case "7": num="&#1639";break;
			case "8": num="&#1640";break;
			case "9": num="&#1641";break;
		}
	return num;
}
/***************
*Punctuation *
 ***************/
function getPunctuation(key) {
	var punct="_";
		switch(key) {
			case ".": punct=".";break;
			case ",": punct="&#1548";break;
			case ";": punct="&#1563";break;
			case "?": punct="&#1567";break;
			case ":": punct=":";break;
		default: break;
		}
	return punct;
}
/***************
*Additional  *
 ***************/
function getOthers(key) {
var others="_";
	switch(key) {
		case "SPACELABEL" : others=getElem("M")+getElem("S")+getElem("A")+getElem("F")+getElem("T1");break;
		case "SPACE"      : others="&#32;" 						  ;break;
		case "CRLABEL"    : others="CR"    						  ;break;
		case "CR"         : others="&#13;" 						  ;break;
	default: break;
	}
return others;
}

/**BUILD-WORDS*/
/**BUILD-WORDS*/
/**BUILD-WORDS*/
/**BUILD-WORDS*/
function buildWords(id,list){var appWords=get(id);var i=0,j=0,row=12;
	var btnWord="<input type='button' value='%PARM' class='_prep' onclick='writeWord(\"%PARM\")'>"
	var table=TABLE,tableCol='';
	while((row*i)<list.length){table+=TR;
		while(((j/row)!=1)&&((row*i+(j+1))<list.length)){
			table+=TD;
			tableCol=btnWord.replace(/%PARM/g,list[row*i+j]);
			table+=tableCol+DT;j++;
		}table+=RT;i++;j=0;
	}table+=TABLE;
	return table;
}
/**BUILD-WORDS*//**BUILD-WORDS*//**BUILD-WORDS*//**BUILD-WORDS*/
/**BUILD-WORDS*//**BUILD-WORDS*//**BUILD-WORDS*//**BUILD-WORDS*/
/**BUILD-WORDS*//**BUILD-WORDS*//**BUILD-WORDS*//**BUILD-WORDS*/
/*****************************\
/* Build preposition section *\
/*****************************/
function buildPreposition(id,list){var lAppContainer=getElem(id);
	var i=0,j=0,table=TABLE,tableCol=null;
	var btnWord="<input type='button' value='%PARM' class='_prep' onclick='writeWord(\"%PARM\")'>"
	table+=TR;
	while((2*i+j)<list.length){table+=TD;
		while(((j/2)!=1)&&((2*i+j)<list.length)){tableCol=btnWord.replace(/%PARM/g, getPrep(list[2*i+j]));table+=tableCol;j++;
		}i++;j=0;table+=TD;
	}table+=RT+ELBAT;
	if(lAppContainer!=null){lAppContainer.innerHTML=table;}
}
/*********************************************
*convert to corresponding arabic alphabet  *
*by pressing of a specified keyboard key   *
 ************************************************************************/
function ConvertToArabChar(key){var AsciiKeyComb=new Array(
'a','A',           /*01*/
'1','e','E','i','I',/*02*/
'b',               /*03*/
't','ö','T',       /*04*/
'g','7','5',       /*05*/
'c','C',           /*06*/
's','S',           /*07*/
'd','D',           /*08*/
'f','q','9',       /*09*/
'k','l','L','m','n',/*10*/
'p','P','4',       /*11*/
'y','Y','h',       /*12*/
'r','R','z','Z',   /*13*/
'3','2',           /*14*/
'w','W',           /*15*/
',','.','?'         /*16*/
);
var mapKeyToArab=new Array(
'ا','ال',                   //1
'ء','أ','آ','إ','ئ',     //2
 'ب',                        //3
 'ت','ة','ث',              //4
 'ج','ح','خ',              //5
 'ص','ض',                   //6
 'س','ش',                   //7
 'د','ذ',                   //8
 'ف','ق','ق',              //9
 'ك','ل','لا','م','ن',    //10
 'ط','ظ','ظ',              //11
 'ي','ى','ه',              //12
 'ر','ز','ز','ز',         //13
 'ع','غ',                   //14
 'و','ؤ',                   //15
 '،','.','؟'                //16
 );
var j=0,found=0,arab='';
/*search engine to convert a keyboard key to an arab alphabet*/
while((j<AsciiKeyComb.length)&&(found==0)){if(AsciiKeyComb[j].match(key)){arab=mapKeyToArab[j];found=1;}j+=1;}
/*default assignement : no convertion has took place*/
if(found==0)arab=key;
return arab;
}
/*                                                                      */
/************************************************************************/
/*********************************************
 * convert to an arab word                   *
 * by pressing of a specified keyboard key   *
 *******************************************************************************/
/*                                                                             */
function ConvertToArabWord(key){var j=0,found=0,arab='';
	var AsciiKeyComb4ArabWord=new Array('M','N','v','V','B','F','x','X','K','J');
	var mapKeyToArabWord=new Array('من','إلى','عن','على','بل','في','مع','الذي','هذا','إنا');
	/*search engine to convert a keyboard key to an arab word*/
	while((j<AsciiKeyComb4ArabWord.length)&&(found==0)){if(AsciiKeyComb4ArabWord[j].match(key)){arab=mapKeyToArabWord[j];found=1;}j+=1;}
	/*default assignement : no convertion has took place*/if(found==0)arab=key;return arab;
}
/*                                                                             */
/*******************************************************************************/
