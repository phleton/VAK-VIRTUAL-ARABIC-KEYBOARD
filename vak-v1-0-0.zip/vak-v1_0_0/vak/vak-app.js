/**vak-app.js*/
/**vak-app.js*/
/**vak-app.js*/
function appConsole(message){console.info(message);}
function appInfo(message){console.info(message);}
function appError(message){console.error(message);}
function appLog(msg){console.log(msg);}
/****************
*Showing Info *
 ****************/
function showInfo(placeHolder){/*show or hide info*/
	var tagElem=getElem(placeHolder);
	if(tagElem!=null){
		if(!isInfoSet){isInfoSet=true;tagElem.style.visibility='visible';
			var _tHeight=tagElem.style.height,_tWidth=tagElem.style.width;
			console.log('width: '+_tWidth+' height: '+_tHeight);
			var _tTop=200;//(screenH / 8)+(parseCssToInt(_tHeight) / 2);
			var _tRight=(screenW*0.5)-(parseCssToInt(_tWidth)*0.5);
			console.log("top: "+_tTop+" right: "+_tRight);
			tagElem.style.top=_tTop+"px";tagElem.style.right=_tRight+"px";/*tagElem.style.display='show';*/
		}else{tagElem.style.visibility='hidden';/*tagElem.style.display='none';*/isInfoSet=false;}
	}
}
/**vak-app.js*/
/**vak-app.js*/
/**vak-app.js*/